/**
 * GET /api/ranking?serie=
 * Ranking consolidado dos alunos, calculado no próprio banco de dados
 * (view vw_ranking_alunos), ordenado por acertos, aproveitamento e tempo.
 */
import { api, getQuery, type ApiRequest, type ApiResponse } from './_lib/http';
import { ranking } from './_lib/repo';

export default api(async (req: ApiRequest, res: ApiResponse) => {
  const serie = (getQuery(req).get('serie') || '').trim();
  const lista = await ranking(serie === 'todos' ? '' : serie);
  res.status(200).json({ ok: true, serie: serie || 'todos', ranking: lista, total: lista.length });
});