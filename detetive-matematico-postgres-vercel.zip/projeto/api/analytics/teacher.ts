/**
 * GET /api/analytics/teacher?serie=
 * Relatório pedagógico: tempo por questão, erros por aluno e temas críticos,
 * calculado diretamente no banco de dados.
 */
import { api, getQuery, type ApiRequest, type ApiResponse } from '../_lib/http';
import { teacherStudentAnalytics, themeOverview } from '../_lib/repo';

export default api(async (req: ApiRequest, res: ApiResponse) => {
  const serie = (getQuery(req).get('serie') || '').trim();
  const filtro = serie === 'todos' ? '' : serie;

  const [alunos, resumo] = await Promise.all([
    teacherStudentAnalytics(filtro),
    themeOverview(filtro)
  ]);

  res.status(200).json({ ok: true, serie: serie || 'todos', alunos, resumo });
});