/**
 * GET  /api/reports  -> relatos para o painel docente
 * POST /api/reports  -> novo relato enviado por aluno
 * PATCH /api/reports -> alterar status para aberto/resolvido
 */
import {
  api,
  asNumber,
  asString,
  badRequest,
  getQuery,
  methodOf,
  readJson,
  type ApiRequest,
  type ApiResponse
} from '../_lib/http';
import {
  insertChallengeReport,
  listChallengeReports,
  updateChallengeReportStatus,
  type ChallengeReport
} from '../_lib/repo';

function normalize(body: Record<string, unknown>): ChallengeReport {
  const descricao = asString(body.descricao).replace(/\s+/g, ' ').trim();
  const modo = asString(body.modo) === 'treine_mais' ? 'treine_mais' : 'oficial';
  const status = asString(body.status) === 'resolvido' ? 'resolvido' : 'aberto';
  if (!asString(body.usuarioId)) throw badRequest('O relato precisa estar vinculado ao aluno.');
  if (!asString(body.alunoNome)) throw badRequest('O nome do aluno é obrigatório.');
  if (!asString(body.desafioNome)) throw badRequest('Informe qual desafio apresentou o problema.');
  if (descricao.length < 5) throw badRequest('Descreva o problema com pelo menos 5 caracteres.');
  if (descricao.length > 500) throw badRequest('A descrição deve ter no máximo 500 caracteres.');
  return {
    id: asString(body.id) || `report-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    usuarioId: asString(body.usuarioId),
    alunoNome: asString(body.alunoNome),
    serie: asString(body.serie),
    desafioNome: asString(body.desafioNome),
    modo,
    descricao,
    status,
    data: asString(body.data) || new Date().toLocaleDateString('pt-BR'),
    timestamp: Math.round(asNumber(body.timestamp, Date.now()))
  };
}

export default api(async (req: ApiRequest, res: ApiResponse) => {
  const method = methodOf(req);
  if (method === 'GET') {
    const params = getQuery(req);
    const reports = await listChallengeReports({
      serie: (params.get('serie') || '').trim(),
      status: (params.get('status') || '').trim(),
      limit: Math.min(asNumber(params.get('limit'), 1000) || 1000, 5000)
    });
    res.status(200).json({ ok: true, reports, total: reports.length });
    return;
  }
  const body = await readJson<Record<string, unknown>>(req);
  if (method === 'POST') {
    const report = normalize(body);
    const saved = await insertChallengeReport(report);
    res.status(201).json({ ok: true, report: saved });
    return;
  }
  if (method === 'PATCH' || method === 'PUT') {
    const id = asString(body.id);
    const status = asString(body.status);
    if (!id || !['aberto', 'resolvido'].includes(status)) {
      throw badRequest('Informe o id e um status válido (aberto ou resolvido).');
    }
    const updated = await updateChallengeReportStatus(id, status as 'aberto' | 'resolvido');
    if (!updated) throw badRequest('Relato não encontrado.', 'NOT_FOUND');
    res.status(200).json({ ok: true, report: updated });
    return;
  }
  throw badRequest('Método não suportado nesta rota.', 'METHOD_NOT_ALLOWED');
});
