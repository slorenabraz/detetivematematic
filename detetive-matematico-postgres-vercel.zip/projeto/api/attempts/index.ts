/**
 * GET  /api/attempts   → tentativas individuais (?serie=, ?usuarioId=, ?limit=)
 * POST /api/attempts   → grava a tentativa de uma questão (diagnóstico do professor)
 */
import { api, asNumber, asString, badRequest, getQuery, readJson, type ApiRequest, type ApiResponse } from '../_lib/http';
import { insertAttempt, listAttempts, type QuestionAttempt } from '../_lib/repo';

function normalize(body: Record<string, unknown>): QuestionAttempt {
  const attempt: QuestionAttempt = {
    id: asString(body.id) || `att-${Date.now()}`,
    usuarioId: asString(body.usuarioId),
    alunoNome: asString(body.alunoNome),
    serie: asString(body.serie),
    modo: asString(body.modo) === 'treine_mais' ? 'treine_mais' : 'oficial',
    etapaNumero: Math.max(1, Math.round(asNumber(body.etapaNumero, 1))),
    temaNome: asString(body.temaNome),
    pergunta: asString(body.pergunta),
    respostaSelecionada: asString(body.respostaSelecionada),
    respostaCorreta: asString(body.respostaCorreta),
    acertou: body.acertou === true,
    tempoGastoSegundos: Math.max(0, asNumber(body.tempoGastoSegundos)),
    data: asString(body.data) || new Date().toLocaleDateString('pt-BR'),
    timestamp: Math.round(asNumber(body.timestamp, Date.now()))
  };

  if (!attempt.usuarioId) throw badRequest('A tentativa precisa estar vinculada a um usuário.');
  if (!attempt.pergunta) throw badRequest('A tentativa precisa registrar a pergunta.');
  return attempt;
}

export default api(async (req: ApiRequest, res: ApiResponse) => {
  const method = (req.method || 'GET').toUpperCase();

  if (method === 'GET') {
    const params = getQuery(req);
    const attempts = await listAttempts({
      serie: (params.get('serie') || '').trim(),
      usuarioId: (params.get('usuarioId') || '').trim(),
      limit: Math.min(asNumber(params.get('limit'), 50000) || 50000, 50000)
    });
    res.status(200).json({ ok: true, attempts, total: attempts.length });
    return;
  }

  if (method === 'POST' || method === 'PUT') {
    const body = await readJson<Record<string, unknown>>(req);
    const attempt = normalize(body);
    const saved = await insertAttempt(attempt);
    res.status(201).json({ ok: true, attempt: saved });
    return;
  }

  throw badRequest('Método não suportado nesta rota.', 'METHOD_NOT_ALLOWED');
});