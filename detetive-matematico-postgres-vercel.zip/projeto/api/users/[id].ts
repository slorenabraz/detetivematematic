/**
 * GET    /api/users/:id   → dados públicos de um usuário
 * PATCH  /api/users/:id   → atualiza a senha   ({ senha })
 * DELETE /api/users/:id   → remove o usuário
 */
import { api, asString, badRequest, getPath, notFound, readJson, type ApiRequest, type ApiResponse } from '../_lib/http';
import { hashPassword, isHashedPassword } from '../_lib/auth';
import { deleteUser, findUserById, updateUserPassword, userRecordToPublic } from '../_lib/repo';

function userIdFromPath(req: ApiRequest): string {
  const segments = getPath(req).split('/').filter(Boolean);
  return decodeURIComponent(segments[segments.length - 1] || '');
}

export default api(async (req: ApiRequest, res: ApiResponse) => {
  const id = userIdFromPath(req);
  if (!id) throw badRequest('Identificador do usuário não informado.');

  const method = (req.method || 'GET').toUpperCase();

  if (method === 'GET') {
    const user = await findUserById(id);
    if (!user) throw notFound('Usuário não encontrado.', 'USER_NOT_FOUND');
    res.status(200).json({ ok: true, user: userRecordToPublic(user) });
    return;
  }

  if (method === 'PATCH' || method === 'PUT') {
    const body = await readJson<Record<string, unknown>>(req);
    const senhaInformada = asString(body.senha || body.novaSenha);
    if (!senhaInformada) throw badRequest('Informe a nova senha.');

    const senha = isHashedPassword(senhaInformada) ? senhaInformada : hashPassword(senhaInformada);
    const user = await updateUserPassword(id, senha);
    if (!user) throw notFound('Usuário não encontrado.', 'USER_NOT_FOUND');
    res.status(200).json({ ok: true, user });
    return;
  }

  if (method === 'DELETE') {
    const removido = await deleteUser(id);
    if (!removido) throw notFound('Usuário não encontrado.', 'USER_NOT_FOUND');
    res.status(200).json({ ok: true, message: 'Usuário removido.' });
    return;
  }

  throw badRequest('Método não suportado nesta rota.', 'METHOD_NOT_ALLOWED');
});