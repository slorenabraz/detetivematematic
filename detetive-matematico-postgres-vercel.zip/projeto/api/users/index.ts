/**
 * GET  /api/users        → lista os usuários cadastrados (sem senhas)
 * POST /api/users        → cria/atualiza um usuário (idempotente pelo id)
 */
import { api, asString, badRequest, conflict, readJson, type ApiRequest, type ApiResponse } from '../_lib/http';
import { hashPassword, isHashedPassword } from '../_lib/auth';
import { DuplicateEmailError, listUsers, upsertUser } from '../_lib/repo';

export default api(async (req: ApiRequest, res: ApiResponse) => {
  const method = (req.method || 'GET').toUpperCase();

  if (method === 'GET') {
    const users = await listUsers();
    res.status(200).json({ ok: true, users, total: users.length });
    return;
  }

  if (method !== 'POST' && method !== 'PUT') {
    throw badRequest('Método não suportado nesta rota.', 'METHOD_NOT_ALLOWED');
  }

  const body = await readJson<Record<string, unknown>>(req);
  const id = asString(body.id) || `usr-${Date.now()}`;
  const nome = asString(body.nome);
  const email = asString(body.email);
  const tipo = asString(body.tipo).toLowerCase() === 'professor' ? 'professor' : 'aluno';
  const serie = asString(body.serie) || (tipo === 'professor' ? 'Corpo Docente' : '');
  const materia = asString(body.materia);
  const senhaInformada = asString(body.senha);

  if (!nome) throw badRequest('O nome do usuário é obrigatório.');
  if (!email) throw badRequest('O e-mail do usuário é obrigatório.');

  // Senha em texto puro é convertida para hash; senha vazia mantém a atual.
  const senha = senhaInformada
    ? isHashedPassword(senhaInformada)
      ? senhaInformada
      : hashPassword(senhaInformada)
    : '';

  try {
    const user = await upsertUser({
      id,
      nome,
      tipo,
      email,
      senha,
      serie,
      materia,
      data_cadastro:
        asString(body.dataCadastro || body.data_cadastro) || new Date().toLocaleDateString('pt-BR')
    });
    res.status(200).json({ ok: true, user });
  } catch (error) {
    if (error instanceof DuplicateEmailError) throw conflict(error.message, 'DUPLICATE_EMAIL');
    throw error;
  }
});