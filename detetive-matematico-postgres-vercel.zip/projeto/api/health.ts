/**
 * GET /api/health
 * Diagnóstico do banco: informa se o PostgreSQL está configurado e acessível.
 * O aplicativo usa esta rota para decidir entre "modo nuvem" e "modo local".
 */
import { api, type ApiRequest, type ApiResponse } from './_lib/http';
import { databaseHost, ensureSchema, isDatabaseConfigured } from './_lib/db';
import { counts } from './_lib/repo';

export default api(
  async (_req: ApiRequest, res: ApiResponse) => {
    if (!isDatabaseConfigured()) {
      res.status(200).json({
        ok: true,
        database: false,
        configured: false,
        mode: 'local',
        message:
          'DATABASE_URL não configurada. O aplicativo funciona normalmente no modo local (dados salvos no navegador).'
      });
      return;
    }

    try {
      await ensureSchema();
      const totals = await counts();
      res.status(200).json({
        ok: true,
        database: true,
        configured: true,
        mode: 'cloud',
        host: databaseHost(),
        schemaVersion: 2,
        counts: totals,
        serverTime: new Date().toISOString()
      });
    } catch (error) {
      res.status(200).json({
        ok: true,
        database: false,
        configured: true,
        mode: 'local',
        host: databaseHost(),
        error: error instanceof Error ? error.message : String(error)
      });
    }
  },
  { database: 'optional' }
);
