/**
 * GET  /api/results   → resultados de sessão (?serie=, ?usuarioId=, ?limit=)
 * POST /api/results   → grava o resultado de um desafio concluído
 */
import { api, asNumber, asString, badRequest, getQuery, readJson, type ApiRequest, type ApiResponse } from '../_lib/http';
import { insertResult, listResults, type SessionResult } from '../_lib/repo';

function normalize(body: Record<string, unknown>): SessionResult {
  const result: SessionResult = {
    id: asString(body.id) || `res-${Date.now()}`,
    usuarioId: asString(body.usuarioId),
    alunoNome: asString(body.alunoNome),
    serie: asString(body.serie),
    modo: asString(body.modo) === 'treine_mais' ? 'treine_mais' : 'oficial',
    etapaNome: asString(body.etapaNome),
    acertos: Math.max(0, Math.round(asNumber(body.acertos))),
    erros: Math.max(0, Math.round(asNumber(body.erros))),
    tempoTotalSegundos: Math.max(0, asNumber(body.tempoTotalSegundos)),
    tempoMedioPorQuestao: Math.max(0, asNumber(body.tempoMedioPorQuestao)),
    data: asString(body.data) || new Date().toLocaleDateString('pt-BR'),
    timestamp: Math.round(asNumber(body.timestamp, Date.now()))
  };

  if (!result.usuarioId) throw badRequest('O resultado precisa estar vinculado a um usuário.');
  if (!result.alunoNome) throw badRequest('O resultado precisa do nome do aluno.');
  return result;
}

export default api(async (req: ApiRequest, res: ApiResponse) => {
  const method = (req.method || 'GET').toUpperCase();

  if (method === 'GET') {
    const params = getQuery(req);
    const results = await listResults({
      serie: (params.get('serie') || '').trim(),
      usuarioId: (params.get('usuarioId') || '').trim(),
      limit: Math.min(asNumber(params.get('limit'), 20000) || 20000, 50000)
    });
    res.status(200).json({ ok: true, results, total: results.length });
    return;
  }

  if (method === 'POST' || method === 'PUT') {
    const body = await readJson<Record<string, unknown>>(req);
    const result = normalize(body);
    const saved = await insertResult(result);
    res.status(201).json({ ok: true, result: saved });
    return;
  }

  throw badRequest('Método não suportado nesta rota.', 'METHOD_NOT_ALLOWED');
});