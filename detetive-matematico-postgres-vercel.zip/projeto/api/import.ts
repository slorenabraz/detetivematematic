/**
 * POST /api/import
 * Entrada: { users?: [], results?: [], attempts?: [] }
 *
 * Migra em lote dados que estavam salvos apenas no navegador (ou vindos de
 * outro sistema). É idempotente: registros com o mesmo id não são duplicados.
 */
import { api, badRequest, ok, readJson, type ApiRequest, type ApiResponse } from './_lib/http';
import { hashPassword, isHashedPassword } from './_lib/auth';
import { importBulk, type QuestionAttempt, type SessionResult, type UserRecord } from './_lib/repo';

type LegacyUser = Omit<UserRecord, 'senha'> & { senha?: string; dataCadastro?: string };

function mapLegacyUser(raw: Record<string, unknown>): LegacyUser | null {
  const id = String(raw.id || '').trim();
  const email = String(raw.email || '').trim();
  if (!id || !email) return null;

  const senhaInformada = String(raw.senha || '');
  const senha = senhaInformada
    ? isHashedPassword(senhaInformada)
      ? senhaInformada
      : hashPassword(senhaInformada)
    : '';

  return {
    id,
    nome: String(raw.nome || '').trim() || 'Detetive',
    tipo: String(raw.tipo || 'aluno') === 'professor' ? 'professor' : 'aluno',
    email,
    senha,
    serie: String(raw.serie || ''),
    materia: String(raw.materia || ''),
    data_cadastro: String(raw.dataCadastro || raw.data_cadastro || '')
  };
}

export default api(async (req: ApiRequest, res: ApiResponse) => {
  if ((req.method || 'GET').toUpperCase() !== 'POST') {
    throw badRequest('Use o método POST para importar dados.', 'METHOD_NOT_ALLOWED');
  }

  const body = await readJson<Record<string, unknown>>(req);
  const usersRaw = Array.isArray(body.users) ? (body.users as Record<string, unknown>[]) : [];
  const resultsRaw = Array.isArray(body.results) ? (body.results as Record<string, unknown>[]) : [];
  const attemptsRaw = Array.isArray(body.attempts) ? (body.attempts as Record<string, unknown>[]) : [];

  if (usersRaw.length + resultsRaw.length + attemptsRaw.length === 0) {
    throw badRequest('Nada para importar.');
  }

  const users = usersRaw.map(mapLegacyUser).filter((u): u is LegacyUser => u !== null);

  const resultados = await importBulk({
    users,
    results: resultsRaw as unknown as SessionResult[],
    attempts: attemptsRaw as unknown as QuestionAttempt[]
  });

  ok(res, {
    importados: resultados,
    message: `Importação concluída: ${resultados.users} usuário(s), ${resultados.results} resultado(s) e ${resultados.attempts} tentativa(s).`
  });
});