/**
 * Utilitários HTTP compartilhados por todas as rotas da API.
 *
 * As mesmas funções rodam em dois ambientes:
 *  - Vercel Serverless Functions (produção)
 *  - Servidor Express de desenvolvimento local (server/dev-server.ts)
 */
import { DatabaseNotConfiguredError, ensureSchema, isDatabaseConfigured } from './db';

export interface ApiRequest {
  method?: string;
  url?: string;
  headers?: Record<string, unknown>;
  body?: unknown;
  [key: string]: unknown;
}

export interface ApiResponse {
  status(code: number): ApiResponse;
  json(data: unknown): void;
  setHeader?(name: string, value: string): void;
  end?(data?: string): void;
  statusCode?: number;
}

export class HttpError extends Error {
  status: number;
  code?: string;
  constructor(status: number, message: string, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export const badRequest = (message: string, code = 'BAD_REQUEST') => new HttpError(400, message, code);
export const unauthorized = (message: string, code = 'UNAUTHORIZED') => new HttpError(401, message, code);
export const notFound = (message = 'Recurso não encontrado.', code = 'NOT_FOUND') => new HttpError(404, message, code);
export const conflict = (message: string, code = 'CONFLICT') => new HttpError(409, message, code);

export function methodOf(req: ApiRequest): string {
  return (req.method || 'GET').toUpperCase();
}

export function getQuery(req: ApiRequest): URLSearchParams {
  try {
    return new URL(req.url || '/', 'http://localhost').searchParams;
  } catch {
    return new URLSearchParams();
  }
}

export function getPath(req: ApiRequest): string {
  try {
    return new URL(req.url || '/', 'http://localhost').pathname;
  } catch {
    return '/';
  }
}

const MAX_BODY_BYTES = 4 * 1024 * 1024; // 4 MB

export async function readJson<T = Record<string, unknown>>(req: ApiRequest): Promise<T> {
  const body = (req as { body?: unknown }).body;

  if (body !== undefined && body !== null) {
    if (typeof body === 'string') {
      if (!body.trim()) return {} as T;
      try {
        return JSON.parse(body) as T;
      } catch {
        throw badRequest('Corpo da requisição não é um JSON válido.', 'INVALID_JSON');
      }
    }
    if (Buffer.isBuffer(body)) {
      try {
        return JSON.parse(body.toString('utf8')) as T;
      } catch {
        throw badRequest('Corpo da requisição não é um JSON válido.', 'INVALID_JSON');
      }
    }
    if (typeof body === 'object') return body as T;
  }

  // Sem body interpretado (stream cru): lê manualmente
  const stream = req as unknown as AsyncIterable<Buffer | string>;
  if (typeof (stream as { [Symbol.asyncIterator]?: unknown })[Symbol.asyncIterator] !== 'function') {
    return {} as T;
  }

  const chunks: Buffer[] = [];
  let total = 0;
  for await (const chunk of stream) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk));
    total += buffer.length;
    if (total > MAX_BODY_BYTES) throw badRequest('Corpo da requisição muito grande.', 'PAYLOAD_TOO_LARGE');
    chunks.push(buffer);
  }
  const raw = Buffer.concat(chunks).toString('utf8').trim();
  if (!raw) return {} as T;
  try {
    return JSON.parse(raw) as T;
  } catch {
    throw badRequest('Corpo da requisição não é um JSON válido.', 'INVALID_JSON');
  }
}

/** Lê um texto do corpo (usado por formulários simples). */
export function asString(value: unknown): string {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

export function asNumber(value: unknown, fallback = 0): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function applyCors(res: ApiResponse): void {
  if (typeof res.setHeader !== 'function') return;
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Cache-Control', 'no-store');
}

export interface ApiOptions {
  /**
   * 'required' (padrão): responde 503 se o banco não estiver configurado.
   * 'optional': deixa o handler decidir (ex.: /api/health em modo local).
   */
  database?: 'required' | 'optional';
}

type Handler = (req: ApiRequest, res: ApiResponse) => Promise<unknown> | unknown;

/**
 * Envolve o handler com CORS, criação automática do esquema, tratamento de
 * erros e resposta JSON padronizada: { ok, ... } ou { ok: false, error }.
 */
export function api(handler: Handler, options: ApiOptions = {}): Handler {
  const database = options.database ?? 'required';

  return async function wrappedHandler(req: ApiRequest, res: ApiResponse) {
    applyCors(res);

    if (methodOf(req) === 'OPTIONS') {
      res.status(204);
      if (typeof res.end === 'function') res.end();
      return;
    }

    try {
      if (database === 'required') {
        if (!isDatabaseConfigured()) throw new DatabaseNotConfiguredError();
        await ensureSchema();
      }
      const result = await handler(req, res);
      return result;
    } catch (error) {
      if (error instanceof DatabaseNotConfiguredError) {
        res.status(503).json({
          ok: false,
          code: 'DATABASE_NOT_CONFIGURED',
          error: error.message
        });
        return;
      }
      if (error instanceof HttpError) {
        res.status(error.status).json({ ok: false, code: error.code, error: error.message });
        return;
      }
      const message = error instanceof Error ? error.message : String(error);
      console.error('[api] erro não tratado:', error);
      res.status(500).json({ ok: false, code: 'INTERNAL_ERROR', error: message });
    }
  };
}

export function ok(res: ApiResponse, data: Record<string, unknown> = {}): void {
  res.status(200).json({ ok: true, ...data });
}