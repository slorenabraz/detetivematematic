/**
 * Repositório: mapeia o banco relacional para o formato usado pelo aplicativo.
 * Todas as consultas são parametrizadas (sem risco de SQL injection).
 */
import { query, queryOne, withTransaction } from './db';

export type UserType = 'aluno' | 'professor';
export type Modo = 'oficial' | 'treine_mais';

export interface UserRecord {
  id: string;
  nome: string;
  tipo: UserType;
  email: string;
  senha: string;
  serie: string;
  materia: string;
  data_cadastro: string;
}

/** Usuário como o app conhece (sem o hash da senha). */
export interface PublicUser {
  id: string;
  nome: string;
  tipo: UserType;
  email: string;
  serie: string;
  materia: string;
  dataCadastro: string;
}

export interface SessionResult {
  id: string;
  usuarioId: string;
  alunoNome: string;
  serie: string;
  modo: Modo;
  etapaNome: string;
  acertos: number;
  erros: number;
  tempoTotalSegundos: number;
  tempoMedioPorQuestao: number;
  data: string;
  timestamp: number;
}

export interface QuestionAttempt {
  id: string;
  usuarioId: string;
  alunoNome: string;
  serie: string;
  modo: Modo;
  etapaNumero: number;
  temaNome: string;
  pergunta: string;
  respostaSelecionada: string;
  respostaCorreta: string;
  acertou: boolean;
  tempoGastoSegundos: number;
  data: string;
  timestamp: number;
}

export interface ChallengeReport {
  id: string;
  usuarioId: string;
  alunoNome: string;
  serie: string;
  desafioNome: string;
  modo: Modo;
  descricao: string;
  status: 'aberto' | 'resolvido';
  data: string;
  timestamp: number;
}

export interface RankingEntry {
  alunoId: string;
  nome: string;
  serie: string;
  totalAcertos: number;
  totalErros: number;
  desafiosConcluidos: number;
  tempoMedioSegundos: number;
  aproveitamento: number;
}

type Row = Record<string, unknown>;

const text = (value: unknown, fallback = ''): string =>
  value === null || value === undefined ? fallback : String(value);

const num = (value: unknown, fallback = 0): number => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

/* -------------------------------------------------------------------------- */
/* Usuários                                                                    */
/* -------------------------------------------------------------------------- */

export function rowToPublicUser(row: Row): PublicUser {
  return {
    id: text(row.id),
    nome: text(row.nome),
    tipo: text(row.tipo) === 'professor' ? 'professor' : 'aluno',
    email: text(row.email),
    serie: text(row.serie),
    materia: text(row.materia),
    dataCadastro: text(row.data_cadastro)
  };
}

export function rowToUserRecord(row: Row): UserRecord {
  return {
    id: text(row.id),
    nome: text(row.nome),
    tipo: text(row.tipo) === 'professor' ? 'professor' : 'aluno',
    email: text(row.email),
    senha: text(row.senha),
    serie: text(row.serie),
    materia: text(row.materia),
    data_cadastro: text(row.data_cadastro)
  };
}

/** Converte um registro completo (com hash de senha) para o formato público. */
export function userRecordToPublic(user: UserRecord): PublicUser {
  return {
    id: user.id,
    nome: user.nome,
    tipo: user.tipo,
    email: user.email,
    serie: user.serie,
    materia: user.materia,
    dataCadastro: user.data_cadastro
  };
 }

export async function listUsers(limit = 5000): Promise<PublicUser[]> {
  const rows = await query(
    `select id, nome, tipo, email, serie, materia, data_cadastro
       from users
      order by criado_em asc, nome asc
      limit $1`,
    [limit]
  );
  return rows.map(rowToPublicUser);
}

export async function findUserByLogin(login: string): Promise<UserRecord | null> {
  const row = await queryOne(
    `select * from users
      where lower(email) = lower($1) or lower(id) = lower($1)
      limit 1`,
    [login]
  );
  return row ? rowToUserRecord(row) : null;
}

export async function findUserByEmail(email: string): Promise<UserRecord | null> {
  const row = await queryOne(`select * from users where lower(email) = lower($1) limit 1`, [email]);
  return row ? rowToUserRecord(row) : null;
}

export async function findUserById(id: string): Promise<UserRecord | null> {
  const row = await queryOne(`select * from users where id = $1 limit 1`, [id]);
  return row ? rowToUserRecord(row) : null;
}

export class DuplicateEmailError extends Error {
  code = 'DUPLICATE_EMAIL';
  constructor(email: string) {
    super(`O e-mail "${email}" já está cadastrado na plataforma.`);
  }
}

/**
 * Insere ou atualiza um usuário.
 * Um campo `senha` vazio NUNCA apaga a senha existente (evita perda de acesso).
 */
export async function upsertUser(
  user: Omit<UserRecord, 'senha'> & { senha?: string }
): Promise<PublicUser> {
  try {
    const row = await queryOne(
      `insert into users (id, nome, tipo, email, senha, serie, materia, data_cadastro)
       values ($1, $2, $3, $4, $5, $6, $7, $8)
       on conflict (id) do update set
         nome          = excluded.nome,
         tipo          = excluded.tipo,
         email         = excluded.email,
         serie         = excluded.serie,
         materia       = excluded.materia,
         data_cadastro = case when excluded.data_cadastro <> '' then excluded.data_cadastro else users.data_cadastro end,
         senha         = case when excluded.senha <> '' then excluded.senha else users.senha end,
         atualizado_em = now()
       returning id, nome, tipo, email, serie, materia, data_cadastro`,
      [
        user.id,
        user.nome,
        user.tipo,
        user.email,
        user.senha || '',
        user.serie || '',
        user.materia || '',
        user.data_cadastro || new Date().toLocaleDateString('pt-BR')
      ]
    );
    return rowToPublicUser(row as Row);
  } catch (error) {
    const code = (error as { code?: string }).code;
    if (code === '23505') throw new DuplicateEmailError(user.email);
    throw error;
  }
}

export async function updateUserPassword(id: string, senhaHash: string): Promise<PublicUser | null> {
  const row = await queryOne(
    `update users set senha = $2, atualizado_em = now()
      where id = $1
      returning id, nome, tipo, email, serie, materia, data_cadastro`,
    [id, senhaHash]
  );
  return row ? rowToPublicUser(row as Row) : null;
}

export async function deleteUser(id: string): Promise<boolean> {
  const rows = await query(`delete from users where id = $1 returning id`, [id]);
  return rows.length > 0;
}

/* -------------------------------------------------------------------------- */
/* Resultados de sessão                                                        */
/* -------------------------------------------------------------------------- */

export function rowToSessionResult(row: Row): SessionResult {
  return {
    id: text(row.id),
    usuarioId: text(row.usuario_id),
    alunoNome: text(row.aluno_nome),
    serie: text(row.serie),
    modo: text(row.modo) === 'treine_mais' ? 'treine_mais' : 'oficial',
    etapaNome: text(row.etapa_nome),
    acertos: num(row.acertos),
    erros: num(row.erros),
    tempoTotalSegundos: num(row.tempo_total_segundos),
    tempoMedioPorQuestao: num(row.tempo_medio_por_questao),
    data: text(row.data),
    timestamp: num(row.timestamp)
  };
}

export async function listResults(options: {
  serie?: string;
  usuarioId?: string;
  limit?: number;
} = {}): Promise<SessionResult[]> {
  const rows = await query(
    `select * from results
      where ($1 = '' or serie = $1)
        and ($2 = '' or usuario_id = $2)
      order by timestamp desc, criado_em desc
      limit $3`,
    [options.serie || '', options.usuarioId || '', options.limit ?? 20000]
  );
  return rows.map(rowToSessionResult);
}

export async function insertResult(result: SessionResult): Promise<SessionResult | null> {
  const row = await queryOne(
    `insert into results
       (id, usuario_id, aluno_nome, serie, modo, etapa_nome, acertos, erros,
        tempo_total_segundos, tempo_medio_por_questao, data, timestamp)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
     on conflict (id) do update set
       acertos = excluded.acertos,
       erros = excluded.erros,
       tempo_total_segundos = excluded.tempo_total_segundos,
       tempo_medio_por_questao = excluded.tempo_medio_por_questao
     returning *`,
    [
      result.id,
      result.usuarioId,
      result.alunoNome,
      result.serie,
      result.modo,
      result.etapaNome,
      result.acertos,
      result.erros,
      result.tempoTotalSegundos,
      result.tempoMedioPorQuestao,
      result.data,
      result.timestamp
    ]
  );
  return row ? rowToSessionResult(row as Row) : null;
}

/* -------------------------------------------------------------------------- */
/* Tentativas individuais                                                      */
/* -------------------------------------------------------------------------- */

export function rowToAttempt(row: Row): QuestionAttempt {
  return {
    id: text(row.id),
    usuarioId: text(row.usuario_id),
    alunoNome: text(row.aluno_nome),
    serie: text(row.serie),
    modo: text(row.modo) === 'treine_mais' ? 'treine_mais' : 'oficial',
    etapaNumero: num(row.etapa_numero, 1),
    temaNome: text(row.tema_nome),
    pergunta: text(row.pergunta),
    respostaSelecionada: text(row.resposta_selecionada),
    respostaCorreta: text(row.resposta_correta),
    acertou: row.acertou === true,
    tempoGastoSegundos: num(row.tempo_gasto_segundos),
    data: text(row.data),
    timestamp: num(row.timestamp)
  };
}

export async function listAttempts(options: {
  serie?: string;
  usuarioId?: string;
  limit?: number;
} = {}): Promise<QuestionAttempt[]> {
  const rows = await query(
    `select * from attempts
      where ($1 = '' or serie = $1)
        and ($2 = '' or usuario_id = $2)
      order by timestamp desc, criado_em desc
      limit $3`,
    [options.serie || '', options.usuarioId || '', options.limit ?? 50000]
  );
  return rows.map(rowToAttempt);
}

export async function insertAttempt(attempt: QuestionAttempt): Promise<QuestionAttempt | null> {
  const row = await queryOne(
    `insert into attempts
       (id, usuario_id, aluno_nome, serie, modo, etapa_numero, tema_nome, pergunta,
        resposta_selecionada, resposta_correta, acertou, tempo_gasto_segundos, data, timestamp)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
     on conflict (id) do update set
       resposta_selecionada = excluded.resposta_selecionada,
       acertou = excluded.acertou,
       tempo_gasto_segundos = excluded.tempo_gasto_segundos
     returning *`,
    [
      attempt.id,
      attempt.usuarioId,
      attempt.alunoNome,
      attempt.serie,
      attempt.modo,
      attempt.etapaNumero || 1,
      attempt.temaNome,
      attempt.pergunta,
      attempt.respostaSelecionada,
      attempt.respostaCorreta,
      attempt.acertou,
      attempt.tempoGastoSegundos,
      attempt.data,
      attempt.timestamp
    ]
  );
  return row ? rowToAttempt(row as Row) : null;
}

/* -------------------------------------------------------------------------- */
/* Relatos de erros enviados pelos alunos                                     */
/* -------------------------------------------------------------------------- */

export function rowToChallengeReport(row: Row): ChallengeReport {
  return {
    id: text(row.id),
    usuarioId: text(row.usuario_id),
    alunoNome: text(row.aluno_nome),
    serie: text(row.serie),
    desafioNome: text(row.desafio_nome),
    modo: text(row.modo) === 'treine_mais' ? 'treine_mais' : 'oficial',
    descricao: text(row.descricao),
    status: text(row.status) === 'resolvido' ? 'resolvido' : 'aberto',
    data: text(row.data),
    timestamp: num(row.timestamp)
  };
}

export async function listChallengeReports(options: {
  serie?: string;
  status?: string;
  limit?: number;
} = {}): Promise<ChallengeReport[]> {
  const rows = await query(
    `select * from challenge_reports
      where ($1 = '' or serie = $1)
        and ($2 = '' or status = $2)
      order by timestamp desc, criado_em desc
      limit $3`,
    [options.serie || '', options.status || '', options.limit ?? 1000]
  );
  return rows.map(rowToChallengeReport);
}

export async function insertChallengeReport(report: ChallengeReport): Promise<ChallengeReport | null> {
  const row = await queryOne(
    `insert into challenge_reports
       (id, usuario_id, aluno_nome, serie, desafio_nome, modo, descricao, status, data, timestamp)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     on conflict (id) do update set descricao = excluded.descricao, status = excluded.status
     returning *`,
    [
      report.id,
      report.usuarioId,
      report.alunoNome,
      report.serie,
      report.desafioNome,
      report.modo,
      report.descricao,
      report.status,
      report.data,
      report.timestamp
    ]
  );
  return row ? rowToChallengeReport(row as Row) : null;
}

export async function updateChallengeReportStatus(id: string, status: 'aberto' | 'resolvido'): Promise<ChallengeReport | null> {
  const row = await queryOne(
    `update challenge_reports set status = $2 where id = $1 returning *`,
    [id, status]
  );
  return row ? rowToChallengeReport(row as Row) : null;
}

/* -------------------------------------------------------------------------- */
/* Consultas agregadas (ranking e painel do professor)                         */
/* -------------------------------------------------------------------------- */

export async function counts(): Promise<{ users: number; results: number; attempts: number }> {
  const [users, results, attempts] = await Promise.all([
    queryOne<{ total: number }>(`select count(*)::int as total from users`),
    queryOne<{ total: number }>(`select count(*)::int as total from results`),
    queryOne<{ total: number }>(`select count(*)::int as total from attempts`)
  ]);
  return {
    users: num(users?.total),
    results: num(results?.total),
    attempts: num(attempts?.total)
  };
}

export async function ranking(serie = ''): Promise<RankingEntry[]> {
  const rows = await query(
    `select * from vw_ranking_alunos
      where ($1 = '' or serie = $1)
      order by total_acertos desc, aproveitamento desc, tempo_medio_segundos asc`,
    [serie]
  );
  return rows.map((row) => ({
    alunoId: text(row.usuario_id),
    nome: text(row.aluno_nome),
    serie: text(row.serie),
    totalAcertos: num(row.total_acertos),
    totalErros: num(row.total_erros),
    desafiosConcluidos: num(row.desafios_concluidos),
    tempoMedioSegundos: num(row.tempo_medio_segundos),
    aproveitamento: num(row.aproveitamento)
  }));
}

export interface TemaStat {
  temaNome: string;
  totalRespostas: number;
  totalErros: number;
  taxaErroPercentual: number;
  tempoMedioSegundos: number;
}

export async function themeOverview(serie = ''): Promise<{
  temasStats: TemaStat[];
  temaCriticoGeral: string;
  tempoMedioGeralEscola: number;
  totalTentativasGeral: number;
}> {
  const [temas, geral] = await Promise.all([
    query(
      `select tema_nome,
              sum(total_respostas)::int     as total_respostas,
              sum(total_erros)::int         as total_erros,
              round(avg(tempo_medio_segundos))::int as tempo_medio_segundos
         from vw_desempenho_por_tema
        where ($1 = '' or serie = $1)
        group by tema_nome`,
      [serie]
    ),
    queryOne<{ total: number; tempo: number }>(
      `select count(*)::int as total, coalesce(round(avg(tempo_gasto_segundos)), 0)::int as tempo
         from attempts
        where ($1 = '' or serie = $1)`,
      [serie]
    )
  ]);

  const temasStats: TemaStat[] = temas
    .map((row) => {
      const total = num(row.total_respostas);
      const erros = num(row.total_erros);
      return {
        temaNome: text(row.tema_nome),
        totalRespostas: total,
        totalErros: erros,
        taxaErroPercentual: total > 0 ? Math.round((erros / total) * 100) : 0,
        tempoMedioSegundos: num(row.tempo_medio_segundos)
      };
    })
    .sort((a, b) => b.taxaErroPercentual - a.taxaErroPercentual);

  const temaCriticoGeral =
    temasStats.length > 0 && temasStats[0].totalErros > 0
      ? `${temasStats[0].temaNome} (${temasStats[0].taxaErroPercentual}% de erros)`
      : 'Nenhum tema com erros elevados';

  return {
    temasStats,
    temaCriticoGeral,
    tempoMedioGeralEscola: num(geral?.tempo),
    totalTentativasGeral: num(geral?.total)
  };
}

export interface StudentAnalytics {
  alunoId: string;
  nome: string;
  serie: string;
  totalPerguntas: number;
  totalAcertos: number;
  totalErros: number;
  tempoMedioPorPergunta: number;
  temaMaisErros: string;
  tentativasDetalhes: QuestionAttempt[];
}

/** Mesmo formato usado pelo painel do professor no aplicativo. */
export async function teacherStudentAnalytics(serie = ''): Promise<StudentAnalytics[]> {
  const [students, attempts] = await Promise.all([
    query(
      `select id, nome, serie from users
        where tipo = 'aluno' and ($1 = '' or serie = $1)
        order by nome asc`,
      [serie]
    ),
    listAttempts({ serie })
  ]);

  const map = new Map<string, { alunoId: string; nome: string; serie: string; tentativas: QuestionAttempt[] }>();

  students.forEach((row) => {
    const id = text(row.id);
    map.set(id, { alunoId: id, nome: text(row.nome), serie: text(row.serie), tentativas: [] });
  });

  attempts.forEach((attempt) => {
    if (!map.has(attempt.usuarioId)) {
      map.set(attempt.usuarioId, {
        alunoId: attempt.usuarioId,
        nome: attempt.alunoNome,
        serie: attempt.serie,
        tentativas: []
      });
    }
    map.get(attempt.usuarioId)!.tentativas.push(attempt);
  });

  return Array.from(map.values())
    .map((student) => {
      const total = student.tentativas.length;
      const acertos = student.tentativas.filter((t) => t.acertou).length;
      const somaTempo = student.tentativas.reduce((acc, cur) => acc + (cur.tempoGastoSegundos || 20), 0);

      const errosPorTema: Record<string, number> = {};
      student.tentativas
        .filter((t) => !t.acertou)
        .forEach((t) => {
          errosPorTema[t.temaNome] = (errosPorTema[t.temaNome] || 0) + 1;
        });

      let temaMaisErros = 'Nenhum erro registrado';
      let maxErros = 0;
      Object.entries(errosPorTema).forEach(([tema, total]) => {
        if (total > maxErros) {
          maxErros = total;
          temaMaisErros = `${tema} (${total} erro${total > 1 ? 's' : ''})`;
        }
      });

      return {
        alunoId: student.alunoId,
        nome: student.nome,
        serie: student.serie,
        totalPerguntas: total,
        totalAcertos: acertos,
        totalErros: total - acertos,
        tempoMedioPorPergunta: total > 0 ? Math.round(somaTempo / total) : 0,
        temaMaisErros:
          maxErros > 0 ? temaMaisErros : total > 0 ? 'Excelente! Zero erros' : 'Sem atividades registradas',
        tentativasDetalhes: student.tentativas.sort((a, b) => b.timestamp - a.timestamp)
      };
    })
    .sort((a, b) => b.totalPerguntas - a.totalPerguntas);
}

/* -------------------------------------------------------------------------- */
/* Importação em lote (migração de dados locais/legados)                       */
/* -------------------------------------------------------------------------- */

export async function importBulk(payload: {
  users?: Array<Omit<UserRecord, 'senha'> & { senha?: string }>;
  results?: SessionResult[];
  attempts?: QuestionAttempt[];
}): Promise<{ users: number; results: number; attempts: number }> {
  let users = 0;
  let results = 0;
  let attempts = 0;

  await withTransaction(async (client) => {
    for (const user of payload.users || []) {
      if (!user?.id || !user?.email) continue;
      await client.query(
        `insert into users (id, nome, tipo, email, senha, serie, materia, data_cadastro)
         values ($1,$2,$3,$4,$5,$6,$7,$8)
         on conflict (id) do update set
           nome = excluded.nome,
           tipo = excluded.tipo,
           serie = excluded.serie,
           materia = excluded.materia,
           senha = case when excluded.senha <> '' then excluded.senha else users.senha end,
           atualizado_em = now()`,
        [
          user.id,
          user.nome,
          user.tipo === 'professor' ? 'professor' : 'aluno',
          user.email,
          user.senha || '',
          user.serie || '',
          user.materia || '',
          user.data_cadastro || ''
        ]
      );
      users += 1;
    }

    for (const result of payload.results || []) {
      if (!result?.id || !result?.usuarioId) continue;
      await client.query(
        `insert into results
           (id, usuario_id, aluno_nome, serie, modo, etapa_nome, acertos, erros,
            tempo_total_segundos, tempo_medio_por_questao, data, timestamp)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
         on conflict (id) do nothing`,
        [
          result.id,
          result.usuarioId,
          result.alunoNome || '',
          result.serie || '',
          result.modo === 'treine_mais' ? 'treine_mais' : 'oficial',
          result.etapaNome || '',
          num(result.acertos),
          num(result.erros),
          num(result.tempoTotalSegundos),
          num(result.tempoMedioPorQuestao),
          result.data || '',
          num(result.timestamp)
        ]
      );
      results += 1;
    }

    for (const attempt of payload.attempts || []) {
      if (!attempt?.id || !attempt?.usuarioId) continue;
      await client.query(
        `insert into attempts
           (id, usuario_id, aluno_nome, serie, modo, etapa_numero, tema_nome, pergunta,
            resposta_selecionada, resposta_correta, acertou, tempo_gasto_segundos, data, timestamp)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
         on conflict (id) do nothing`,
        [
          attempt.id,
          attempt.usuarioId,
          attempt.alunoNome || '',
          attempt.serie || '',
          attempt.modo === 'treine_mais' ? 'treine_mais' : 'oficial',
          num(attempt.etapaNumero, 1),
          attempt.temaNome || '',
          attempt.pergunta || '',
          attempt.respostaSelecionada || '',
          attempt.respostaCorreta || '',
          attempt.acertou === true,
          num(attempt.tempoGastoSegundos),
          attempt.data || '',
          num(attempt.timestamp)
        ]
      );
      attempts += 1;
    }
  });

  return { users, results, attempts };
}
