/**
 * Conexão com o PostgreSQL + criação automática do esquema.
 *
 * Funciona com qualquer Postgres acessível por URL, incluindo:
 * Neon, Vercel Postgres, Supabase, Railway, Render, RDS, Docker...
 *
 * Variáveis aceitas (a primeira encontrada é usada):
 *   DATABASE_URL, POSTGRES_URL, POSTGRES_PRISMA_URL,
 *   DATABASE_URL_UNPOOLED, POSTGRES_URL_NON_POOLING
 * Opcional: DATABASE_SSL=false (desliga SSL em bancos locais), DATABASE_POOL_MAX
 */
import pg from 'pg';
import { SCHEMA_SQL } from './schema';

const { Pool } = pg;

export class DatabaseNotConfiguredError extends Error {
  code = 'DATABASE_NOT_CONFIGURED';
  constructor() {
    super('Banco de dados não configurado. Defina a variável de ambiente DATABASE_URL no projeto da Vercel.');
  }
}


function firstEnv(...names: string[]): string {
  for (const name of names) {
    const value = (process.env[name] || '').trim();
    if (value) return value;
  }
  return '';
}

export function databaseUrl(): string {
  return firstEnv(
    'DATABASE_URL',
    'POSTGRES_URL',
    'POSTGRES_PRISMA_URL',
    'DATABASE_URL_UNPOOLED',
    'POSTGRES_URL_NON_POOLING'
  );
}

export function isDatabaseConfigured(): boolean {
  return databaseUrl().length > 0;
}

/** Nome do host (sem credenciais) para exibir em diagnósticos. */
export function databaseHost(): string {
  try {
    return new URL(databaseUrl()).hostname || 'desconhecido';
  } catch {
    return 'desconhecido';
  }
}

function sslConfig(url: string): boolean | { rejectUnauthorized: boolean } {
  if (process.env.DATABASE_SSL === 'false') return false;
  if (process.env.DATABASE_SSL === 'true') return { rejectUnauthorized: false };
  try {
    const host = new URL(url).hostname;
    if (host === 'localhost' || host === '127.0.0.1' || host === '::1' || host.endsWith('.local')) {
      return false;
    }
  } catch {
    /* URL inválida: segue com SSL permissivo */
  }
  // Provedores gerenciados (Neon, Supabase, Vercel Postgres...) usam certificados
  // válidos, mas o pooler exige SSL; aceitamos o certificado para evitar erros de CA.
  return { rejectUnauthorized: false };
}

const globalForPg = globalThis as unknown as { __detetiveMatematicoPool?: pg.Pool };

export function getPool(): pg.Pool {
  if (!isDatabaseConfigured()) throw new DatabaseNotConfiguredError();
  if (!globalForPg.__detetiveMatematicoPool) {
    const url = databaseUrl();
    const pool = new Pool({
      connectionString: url,
      ssl: sslConfig(url),
      max: Number(process.env.DATABASE_POOL_MAX || 3),
      idleTimeoutMillis: 10_000,
      connectionTimeoutMillis: 15_000,
      allowExitOnIdle: true
    });
    pool.on('error', (error) => {
      console.error('[db] erro inesperado na conexão:', error);
    });
    globalForPg.__detetiveMatematicoPool = pool;
  }
  return globalForPg.__detetiveMatematicoPool;
}

/** Executa uma consulta e devolve as linhas. */
export async function query<T extends pg.QueryResultRow = pg.QueryResultRow>(
  text: string,
  params: unknown[] = []
): Promise<T[]> {
  const result = await getPool().query<T>(text, params as never[]);
  return result.rows;
}

/** Executa uma consulta e devolve a primeira linha (ou null). */
export async function queryOne<T extends pg.QueryResultRow = pg.QueryResultRow>(
  text: string,
  params: unknown[] = []
): Promise<T | null> {
  const rows = await query<T>(text, params);
  return rows.length > 0 ? rows[0] : null;
}

const globalSchema = globalThis as unknown as { __detetiveMatematicoSchema?: Promise<void> };

/**
 * Garante que todas as tabelas/índices/views existem. O banco começa vazio;
 * usuários entram somente pelo cadastro da plataforma.
 */
export function ensureSchema(): Promise<void> {
  if (!globalSchema.__detetiveMatematicoSchema) {
    globalSchema.__detetiveMatematicoSchema = (async () => {
      const pool = getPool();
      const client = await pool.connect();
      try {
        await client.query(SCHEMA_SQL);
      } finally {
        client.release();
      }
    })().catch((error) => {
      // Permite nova tentativa na próxima requisição em caso de falha temporária
      globalSchema.__detetiveMatematicoSchema = undefined;
      throw error;
    });
  }
  return globalSchema.__detetiveMatematicoSchema;
}

/** Executa um bloco dentro de uma transação. */
export async function withTransaction<T>(fn: (client: pg.PoolClient) => Promise<T>): Promise<T> {
  const pool = getPool();
  const client = await pool.connect();
  try {
    await client.query('begin');
    const result = await fn(client);
    await client.query('commit');
    return result;
  } catch (error) {
    try {
      await client.query('rollback');
    } catch {
      /* ignora */
    }
    throw error;
  } finally {
    client.release();
  }
}
