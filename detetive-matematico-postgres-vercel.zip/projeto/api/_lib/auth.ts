/**
 * Segurança de credenciais.
 *
 * As senhas são guardadas como hash scrypt com sal aleatório (nativo do Node,
 * sem dependências extras). Senhas legadas em texto puro continuam aceitas no
 * login e são automaticamente convertidas para hash na primeira autenticação.
 */
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

const ALGORITHM = 'scrypt';
const KEY_LENGTH = 64;

export function hashPassword(plain: string): string {
  const salt = randomBytes(16).toString('hex');
  const derived = scryptSync(plain, salt, KEY_LENGTH).toString('hex');
  return `${ALGORITHM}$${salt}$${derived}`;
}

export function isHashedPassword(stored: string): boolean {
  return typeof stored === 'string' && stored.startsWith(`${ALGORITHM}$`);
}

export function verifyPassword(plain: string, stored: string): boolean {
  if (!plain || !stored) return false;

  if (isHashedPassword(stored)) {
    const [, salt, hash] = stored.split('$');
    if (!salt || !hash) return false;
    const expected = Buffer.from(hash, 'hex');
    const derived = scryptSync(plain, salt, KEY_LENGTH);
    if (expected.length !== derived.length) return false;
    return timingSafeEqual(derived, expected);
  }

  // Compatibilidade com cadastros antigos (texto puro, sem distinção de caixa)
  return stored === plain || stored.toLowerCase() === plain.toLowerCase();
}

export interface GoogleProfile {
  email: string;
  nome: string;
  picture?: string;
  emailVerified: boolean;
}

/**
 * Valida um ID token do Google (Google Identity Services) junto ao Google.
 * Retorna o perfil se o token for legítimo.
 */
export async function verifyGoogleIdToken(credential: string): Promise<GoogleProfile | null> {
  if (!credential) return null;
  try {
    const response = await fetch(
      `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`
    );
    if (!response.ok) return null;
    const data = (await response.json()) as Record<string, unknown>;

    const expectedAudience = (process.env.GOOGLE_CLIENT_ID || '').trim();
    if (expectedAudience && data.aud !== expectedAudience) {
      console.warn('[auth] ID token do Google com audience inesperado');
      return null;
    }
    const email = typeof data.email === 'string' ? data.email : '';
    if (!email) return null;

    const verified = data.email_verified === true || data.email_verified === 'true';
    return {
      email,
      nome: typeof data.name === 'string' && data.name ? data.name : email,
      picture: typeof data.picture === 'string' ? data.picture : undefined,
      emailVerified: verified
    };
  } catch (error) {
    console.error('[auth] falha ao validar ID token do Google:', error);
    return null;
  }
}