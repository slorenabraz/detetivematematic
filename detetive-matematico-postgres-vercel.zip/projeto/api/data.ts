/**
 * GET /api/data
 * Devolve todo o conjunto de dados da plataforma (usuários, resultados e
 * tentativas) para sincronizar o cache do aplicativo. É a rota usada pelo
 * cliente para manter ranking, histórico e painel do professor sempre atuais.
 *
 * Parâmetros opcionais: ?serie=, ?usuarioId=, ?limitResults=, ?limitAttempts=
 */
import { api, asNumber, getQuery, type ApiRequest, type ApiResponse } from './_lib/http';
import { counts, listAttempts, listChallengeReports, listResults, listUsers } from './_lib/repo';

const MAX_LIMIT = 50000;

export default api(async (req: ApiRequest, res: ApiResponse) => {
  const params = getQuery(req);
  const serie = (params.get('serie') || '').trim();
  const usuarioId = (params.get('usuarioId') || '').trim();
  const limitResults = Math.min(asNumber(params.get('limitResults'), 20000) || 20000, MAX_LIMIT);
  const limitAttempts = Math.min(asNumber(params.get('limitAttempts'), 50000) || 50000, MAX_LIMIT);

  const [users, results, attempts, reports, totals] = await Promise.all([
    listUsers(),
    listResults({ serie, usuarioId, limit: limitResults }),
    listAttempts({ serie, usuarioId, limit: limitAttempts }),
    listChallengeReports({ serie, limit: 1000 }),
    counts()
  ]);

  res.status(200).json({
    ok: true,
    users,
    results,
    attempts,
    reports,
    counts: totals,
    updatedAt: new Date().toISOString()
  });
});
