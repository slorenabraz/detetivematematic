/**
 * POST /api/auth/google
 * Entrada: { credential, tipo? }
 *
 * O `credential` é o ID token (JWT) devolvido pelo Google Identity Services.
 * O token é validado diretamente com o Google antes de criar/liberar o usuário.
 */
import { api, asString, badRequest, ok, readJson, unauthorized, type ApiRequest, type ApiResponse } from '../_lib/http';
import { verifyGoogleIdToken } from '../_lib/auth';
import { findUserByEmail, upsertUser } from '../_lib/repo';

export default api(async (req: ApiRequest, res: ApiResponse) => {
  if ((req.method || 'GET').toUpperCase() !== 'POST') {
    throw badRequest('Use o método POST para autenticar com o Google.', 'METHOD_NOT_ALLOWED');
  }

  const body = await readJson<Record<string, unknown>>(req);
  const credential = asString(body.credential || body.idToken);
  const tipo = asString(body.tipo).toLowerCase();

  if (!credential) {
    throw badRequest('Credencial do Google ausente. Configure VITE_GOOGLE_CLIENT_ID para habilitar esta entrada.', 'MISSING_CREDENTIAL');
  }

  const profile = await verifyGoogleIdToken(credential);
  if (!profile) {
    throw unauthorized('Não foi possível validar sua conta Google. Tente novamente.', 'INVALID_GOOGLE_TOKEN');
  }

  let user = await findUserByEmail(profile.email);

  if (!user) {
    const isTeacher = tipo === 'professor';

    const created = await upsertUser({
      id: `google-${profile.email.toLowerCase()}`,
      nome: profile.nome,
      tipo: isTeacher ? 'professor' : 'aluno',
      email: profile.email,
      senha: '',
      serie: isTeacher ? 'Corpo Docente' : '9º Ano Fundamental',
      materia: isTeacher ? 'Matemática e Geometria' : '',
      data_cadastro: new Date().toLocaleDateString('pt-BR')
    });

    ok(res, { user: created, created: true, message: 'Conta Google vinculada com sucesso!' });
    return;
  }

  ok(res, {
    user: {
      id: user.id,
      nome: user.nome,
      tipo: user.tipo,
      email: user.email,
      serie: user.serie,
      materia: user.materia,
      dataCadastro: user.data_cadastro
    },
    created: false,
    message: 'Login com Google realizado com sucesso.'
  });
});
