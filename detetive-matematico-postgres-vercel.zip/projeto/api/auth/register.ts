/**
 * POST /api/auth/register
 * Entrada: { nome, tipo: 'aluno' | 'professor', email, senha, serie?, materia? }
 * Cria o cadastro do aluno ou professor no banco de dados.
 */
import { api, asString, badRequest, conflict, ok, readJson, type ApiRequest, type ApiResponse } from '../_lib/http';
import { hashPassword } from '../_lib/auth';
import { findUserByEmail, findUserById, upsertUser, DuplicateEmailError } from '../_lib/repo';

export default api(async (req: ApiRequest, res: ApiResponse) => {
  if ((req.method || 'GET').toUpperCase() !== 'POST') {
    throw badRequest('Use o método POST para cadastrar.', 'METHOD_NOT_ALLOWED');
  }

  const body = await readJson<Record<string, unknown>>(req);
  const nome = asString(body.nome);
  const email = asString(body.email);
  const senha = asString(body.senha);
  const tipo = asString(body.tipo).toLowerCase() === 'professor' ? 'professor' : 'aluno';
  const serie = tipo === 'aluno' ? asString(body.serie) || '9º Ano Fundamental' : 'Corpo Docente';
  const materia = tipo === 'professor' ? asString(body.materia) || 'Matemática' : '';

  if (!nome) throw badRequest('Por favor, informe seu nome completo.');
  if (!email) throw badRequest('Por favor, informe seu e-mail institucional ou identificador/RA.');

  if (tipo === 'professor') {
    if (senha.length < 3 || senha.length > 8) {
      throw badRequest('A senha do professor deve conter entre 3 e 8 caracteres.');
    }
  } else if (senha.length < 3) {
    throw badRequest('A senha do aluno deve ter no mínimo 3 caracteres.');
  }

  const normalized = email.toLowerCase();
  const [porEmail, porId] = await Promise.all([findUserByEmail(normalized), findUserById(normalized)]);
  if (porEmail || porId) {
    throw conflict('Atenção: Este e-mail ou usuário de acesso já está cadastrado.', 'DUPLICATE_USER');
  }

  const id = asString(body.id) || `usr-${Date.now()}`;

  try {
    const user = await upsertUser({
      id,
      nome,
      tipo,
      email,
      senha: hashPassword(senha),
      serie,
      materia,
      data_cadastro: asString(body.dataCadastro) || new Date().toLocaleDateString('pt-BR')
    });

    ok(res, { user, message: 'Cadastro realizado com sucesso! Suas informações foram salvas.' });
  } catch (error) {
    if (error instanceof DuplicateEmailError) throw conflict(error.message, 'DUPLICATE_USER');
    throw error;
  }
});