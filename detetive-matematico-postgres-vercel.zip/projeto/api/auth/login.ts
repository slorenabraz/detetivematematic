/**
 * POST /api/auth/login
 * Entrada: { login | email | usuario, senha, tipo? }
 * Aceita e-mail institucional, RA/usuário ou e-mail pessoal, sem distinção
 * entre maiúsculas e minúsculas — igual ao comportamento original do app.
 */
import { api, asString, badRequest, ok, readJson, unauthorized, type ApiRequest, type ApiResponse } from '../_lib/http';
import { hashPassword, isHashedPassword, verifyPassword } from '../_lib/auth';
import { findUserByLogin, updateUserPassword, userRecordToPublic } from '../_lib/repo';

const CREDENCIAIS_INVALIDAS = 'E-mail/usuário ou senha incorretos. Verifique seus dados.';

export default api(async (req: ApiRequest, res: ApiResponse) => {
  if ((req.method || 'GET').toUpperCase() !== 'POST') {
    throw badRequest('Use o método POST para autenticar.', 'METHOD_NOT_ALLOWED');
  }

  const body = await readJson<Record<string, unknown>>(req);
  const login = asString(body.login || body.email || body.usuario).toLowerCase();
  const senha = asString(body.senha || body.password);
  const tipo = asString(body.tipo);

  if (!login) throw badRequest('Informe o e-mail institucional, RA ou usuário.');
  if (!senha) throw badRequest('Informe a senha.');

  const user = await findUserByLogin(login);
  if (!user) throw unauthorized(CREDENCIAIS_INVALIDAS, 'INVALID_CREDENTIALS');

  if (!verifyPassword(senha, user.senha)) {
    throw unauthorized(CREDENCIAIS_INVALIDAS, 'INVALID_CREDENTIALS');
  }

  // Migração transparente: senhas antigas em texto puro passam a ser hash.
  if (!isHashedPassword(user.senha)) {
    try {
      await updateUserPassword(user.id, hashPassword(senha));
    } catch (error) {
      console.warn('[auth] não foi possível converter a senha legada para hash:', error);
    }
  }

  ok(res, {
    user: userRecordToPublic(user),
    message: 'Login realizado com sucesso.',
    tipoInformado: tipo || null
  });
});
