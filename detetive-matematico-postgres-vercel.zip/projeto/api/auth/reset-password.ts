/**
 * POST /api/auth/reset-password
 * Entrada: { login | email, novaSenha }
 * Redefine a senha de alunos e professores e persiste a alteração no banco.
 */
import { api, asString, badRequest, notFound, ok, readJson, type ApiRequest, type ApiResponse } from '../_lib/http';
import { hashPassword } from '../_lib/auth';
import { findUserByLogin, updateUserPassword, userRecordToPublic } from '../_lib/repo';

export default api(async (req: ApiRequest, res: ApiResponse) => {
  if ((req.method || 'GET').toUpperCase() !== 'POST') {
    throw badRequest('Use o método POST para redefinir a senha.', 'METHOD_NOT_ALLOWED');
  }

  const body = await readJson<Record<string, unknown>>(req);
  const login = asString(body.login || body.email || body.usuario).toLowerCase();
  const novaSenha = asString(body.novaSenha || body.senha);

  if (!login) throw badRequest('Por favor, informe seu e-mail institucional ou usuário cadastrado.');
  if (!novaSenha) throw badRequest('Por favor, informe a nova senha.');

  const user = await findUserByLogin(login);
  if (!user) {
    throw notFound(`E-mail ou usuário "${login}" não encontrado na plataforma.`, 'USER_NOT_FOUND');
  }

  if (user.tipo === 'professor') {
    if (novaSenha.length < 3 || novaSenha.length > 8) {
      throw badRequest('A senha deve conter entre 3 e 8 caracteres.');
    }
  } else if (novaSenha.length < 3) {
    throw badRequest('A nova senha deve ter no mínimo 3 caracteres.');
  }

  const updated = await updateUserPassword(user.id, hashPassword(novaSenha));
  if (!updated) throw notFound('Não foi possível atualizar a senha deste usuário.', 'USER_NOT_FOUND');

  ok(res, {
    user: updated,
    message: `Senha redefinida com sucesso para o usuário ${userRecordToPublic(user).nome}! Suas informações foram salvas.`
  });
});