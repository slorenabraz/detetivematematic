export type UserType = 'aluno' | 'professor';

export interface User {
  id: string;
  nome: string;
  tipo: UserType;
  email: string;
  senha: string;
  serie: string; // e.g. "9º Ano Fundamental", "1º Ano Ensino Médio", etc.
  materia?: string; // Disciplina que o professor ministra (e.g. "Matemática", "Geometria", etc.)
  dataCadastro: string;
}

export const DISCIPLINAS_ESCOLARES = [
  'Matemática',
  'Geometria',
  'Trigonometria',
  'Matemática e Geometria',
  'Cálculo e Álgebra',
  'Física',
  'Química',
  'Ciências',
  'Ciências da Natureza',
  'Biologia',
  'Língua Portuguesa',
  'Literatura',
  'Redação',
  'Língua Inglesa (Inglês)',
  'Língua Espanhola (Espanhol)',
  'Arte / Artes Visuais',
  'Educação Física',
  'História',
  'Geografia',
  'Filosofia',
  'Sociologia',
  'Projeto de Vida',
  'Tecnologia e Inovação',
  'Robótica',
  'Eletivas / Itinerários Formativos'
];

export type ThemeType = 
  | 'pitagoras'
  | 'senos'
  | 'cossenos'
  | 'semelhanca'
  | 'trig_iniciante'
  | 'trig_intermediario'
  | 'trig_avancado';

export interface Question {
  id: string;
  etapa?: number; // 1 to 4 for Desafios Oficiais
  nivel?: 'iniciante' | 'intermediario' | 'avancado'; // for Treine Mais
  temaKey: ThemeType;
  temaNome: string;
  pergunta: string;
  opcoes: string[];
  correta: number; // Index of the correct (or inverted false) option
  porque?: string;
  svgType?: string;
  invertida?: boolean; // In official challenges, finding the FALSE option
  dicaInvestigacao?: string; // Dica pedagógica e conceito geométrico
}

export interface QuestionAttempt {
  id: string;
  usuarioId: string;
  alunoNome: string;
  serie: string;
  modo: 'oficial' | 'treine_mais';
  etapaNumero?: number;
  temaNome: string;
  pergunta: string;
  respostaSelecionada: string;
  respostaCorreta: string;
  acertou: boolean;
  tempoGastoSegundos: number; // Time student stayed on this question
  data: string;
  timestamp: number;
}

export interface SessionResult {
  id: string;
  usuarioId: string;
  alunoNome: string;
  serie: string;
  modo: 'oficial' | 'treine_mais';
  etapaNome: string;
  acertos: number;
  erros: number;
  tempoTotalSegundos: number;
  tempoMedioPorQuestao: number;
  data: string;
  timestamp: number;
}

export interface ChallengeReport {
  id: string;
  usuarioId: string;
  alunoNome: string;
  serie: string;
  desafioNome: string;
  modo: 'oficial' | 'treine_mais';
  descricao: string;
  status: 'aberto' | 'resolvido';
  data: string;
  timestamp: number;
}

export interface TeacherThemeStats {
  temaNome: string;
  totalRespostas: number;
  totalErros: number;
  taxaErroPercentual: number;
  tempoMedioSegundos: number;
}
