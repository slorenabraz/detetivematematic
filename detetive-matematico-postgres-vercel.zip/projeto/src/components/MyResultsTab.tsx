import React, { useMemo } from 'react';
import { User } from '../types';
import { Storage } from '../utils/storage';
import { TrendingUp, Award, Target, Calendar, CheckCircle2, XCircle } from 'lucide-react';

interface MyResultsTabProps {
  currentUser: User | null;
  onOpenAuth: () => void;
  onNavigate: (page: string) => void;
}

export const MyResultsTab: React.FC<MyResultsTabProps> = ({
  currentUser,
  onOpenAuth,
  onNavigate
}) => {
  const [version, setVersion] = React.useState(0);

  // Acompanha as atualizações do banco de dados PostgreSQL
  React.useEffect(() => {
    const unsubscribe = Storage.subscribe(() => {
      setVersion((v) => v + 1);
    });
    return unsubscribe;
  }, []);

  const userResults = useMemo(() => {
    if (!currentUser) return [];
    return Storage.getResults()
      .filter((r) => r.usuarioId === currentUser.id)
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [currentUser, version]);

  const userAttempts = useMemo(() => {
    if (!currentUser) return [];
    return Storage.getAttempts()
      .filter((a) => a.usuarioId === currentUser.id)
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [currentUser, version]);

  if (!currentUser) {
    return (
      <div className="bg-[#0b1329]/80 backdrop-blur-xl rounded-3xl p-8 sm:p-12 shadow-[0_0_30px_rgba(0,240,255,0.15)] border border-cyan-500/30 text-center max-w-xl mx-auto space-y-6">
        <div className="w-16 h-16 bg-amber-500/20 border border-amber-500/40 text-amber-300 rounded-3xl flex items-center justify-center text-3xl mx-auto shadow-sm">
          🔍
        </div>
        <div className="space-y-2">
          <h3 className="text-2xl font-black text-white">
            Histórico Pessoal de Desempenho
          </h3>
          <p className="text-slate-300 text-sm leading-relaxed">
            Faça login para acompanhar suas estatísticas, tempo médio por questão e histórico de desafios completados!
          </p>
        </div>
        <button
          onClick={onOpenAuth}
          className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black px-8 py-3.5 rounded-2xl transition shadow-[0_0_20px_rgba(0,240,255,0.4)] inline-flex items-center gap-2 text-sm cursor-pointer"
        >
          Fazer Login Agora
        </button>
      </div>
    );
  }

  const totalAcertos = userResults.reduce((acc, r) => acc + r.acertos, 0);
  const totalErros = userResults.reduce((acc, r) => acc + r.erros, 0);
  const totalQuestoes = totalAcertos + totalErros;
  const aproveitamento = totalQuestoes > 0 ? Math.round((totalAcertos / totalQuestoes) * 100) : 0;
  const tempoMedio =
    userAttempts.length > 0
      ? Math.round(
          userAttempts.reduce((acc, a) => acc + (a.tempoGastoSegundos || 20), 0) / userAttempts.length
        )
      : 25;

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Banner */}
      <div className="bg-[#0b1329]/90 border border-cyan-500/30 text-white p-6 sm:p-8 rounded-3xl shadow-[0_0_25px_rgba(0,240,255,0.15)] backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center sm:text-left">
          <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-black px-3.5 py-1 rounded-full uppercase tracking-wider inline-block">
            Histórico Individual do Aluno
          </span>
          <h2 className="text-2xl sm:text-3xl font-black flex items-center justify-center sm:justify-start gap-2.5">
            <TrendingUp className="w-8 h-8 text-emerald-400" /> Meus Resultados e Conquistas
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm max-w-xl">
            Detetive <strong className="text-cyan-300">{currentUser.nome}</strong> ({currentUser.serie})
          </p>
        </div>

        <button
          onClick={() => onNavigate('desafios')}
          className="bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-black px-5 py-3 rounded-2xl border-2 border-amber-300/80 neon-glow-btn-amber transition text-xs sm:text-sm flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <Target className="w-4 h-4 fill-slate-950" /> Jogar Novo Desafio
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#0b1329]/80 backdrop-blur-xl p-5 rounded-3xl border border-cyan-500/30 shadow-md text-center space-y-1">
          <span className="text-[10px] text-slate-400 font-extrabold uppercase block">Desafios Concluídos</span>
          <span className="text-2xl sm:text-3xl font-black text-white font-mono">{userResults.length}</span>
        </div>

        <div className="bg-[#0b1329]/80 backdrop-blur-xl p-5 rounded-3xl border border-cyan-500/30 shadow-md text-center space-y-1">
          <span className="text-[10px] text-slate-400 font-extrabold uppercase block">Total de Acertos</span>
          <span className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">{totalAcertos}</span>
        </div>

        <div className="bg-[#0b1329]/80 backdrop-blur-xl p-5 rounded-3xl border border-cyan-500/30 shadow-md text-center space-y-1">
          <span className="text-[10px] text-slate-400 font-extrabold uppercase block">Taxa de Precisão</span>
          <span className="text-2xl sm:text-3xl font-black text-cyan-300 font-mono">{aproveitamento}%</span>
        </div>

        <div className="bg-[#0b1329]/80 backdrop-blur-xl p-5 rounded-3xl border border-cyan-500/30 shadow-md text-center space-y-1">
          <span className="text-[10px] text-slate-400 font-extrabold uppercase block">Tempo Médio p/ Questão</span>
          <span className="text-2xl sm:text-3xl font-black text-amber-300 font-mono">{tempoMedio}s</span>
        </div>
      </div>

      {/* History List */}
      <div className="bg-[#0b1329]/80 backdrop-blur-xl rounded-3xl shadow-xl border border-cyan-500/30 overflow-hidden space-y-4">
        <div className="p-6 border-b border-cyan-500/20 flex items-center justify-between">
          <h3 className="font-black text-lg text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" /> Registro de Desafios Oficiais Concluídos
          </h3>
          <span className="text-xs text-cyan-300 font-mono">
            {userResults.length} registro(s)
          </span>
        </div>

        {userResults.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-2">
            <Target className="w-12 h-12 text-slate-600 mx-auto" />
            <p className="text-base font-bold text-slate-300">Você ainda não concluiu nenhum Desafio Oficial</p>
            <p className="text-xs text-slate-500">
              Acesse a aba Desafios e inicie sua investigação matemática para registrar pontuações!
            </p>
          </div>
        ) : (
          <div className="divide-y divide-cyan-500/10">
            {userResults.map((r) => (
              <div
                key={r.id}
                className="p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-cyan-950/20 transition"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-white text-sm sm:text-base">
                      {r.etapaNome}
                    </span>
                    <span className="text-[10px] font-bold text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded-full border border-cyan-500/40 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {r.data}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400 block">
                    Série: {r.serie} • Tempo médio: {r.tempoMedioPorQuestao || 25}s por questão
                  </span>
                </div>

                <div className="flex items-center gap-6 self-end sm:self-center">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">Resultado</span>
                    <div className="flex items-center gap-2 text-xs sm:text-sm font-bold font-mono">
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> {r.acertos}
                      </span>
                      <span className="text-rose-400 flex items-center gap-1">
                        <XCircle className="w-4 h-4" /> {r.erros}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">Status</span>
                    <span className="text-xs font-bold text-emerald-300 bg-emerald-950/60 border border-emerald-500/40 px-3 py-1 rounded-full inline-block">
                      Concluído
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
