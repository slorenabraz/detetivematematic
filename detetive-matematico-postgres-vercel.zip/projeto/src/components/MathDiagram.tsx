import React from 'react';

interface MathDiagramProps {
  type?: string;
  className?: string;
}

export const MathDiagram: React.FC<MathDiagramProps> = ({ type, className = "w-full max-w-xs h-auto" }) => {
  switch (type) {
    case 'triangulo_seno':
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <path d="M 30,95 L 160,95 L 160,25 Z" stroke="#00f0ff" strokeWidth="2.5" fill="#00f0ff" fillOpacity="0.1" />
          <rect x="145" y="80" width="15" height="15" stroke="#38bdf8" strokeWidth="1.5" fill="none" />
          <circle cx="152" cy="88" r="2" fill="#00f0ff" />
          <text x="75" y="110" fontSize="10" fontWeight="bold" fill="#38bdf8">Cateto Adjacente</text>
          <text x="165" y="65" fontSize="10" fontWeight="bold" fill="#38bdf8">Cat. Oposto</text>
          <text x="70" y="50" fontSize="11" fontWeight="bold" fill="#ffbc00">Hipotenusa</text>
          <path d="M 50,95 A 20,20 0 0,0 45,85" stroke="#ffbc00" strokeWidth="2" fill="none" />
          <text x="55" y="90" fontSize="10" fontWeight="bold" fill="#ffbc00">θ</text>
        </svg>
      );

    case 'triangulo_tangente':
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <path d="M 25,95 L 160,95 L 160,25 Z" stroke="#38bdf8" strokeWidth="2.5" fill="#38bdf8" fillOpacity="0.1" />
          <text x="65" y="112" fontSize="10" fontWeight="bold" fill="#38bdf8">Cateto Adjacente (CA)</text>
          <text x="165" y="65" fontSize="10" fontWeight="bold" fill="#00f0ff">Cateto Oposto (CO)</text>
          <text x="70" y="45" fontSize="11" fontWeight="bold" fill="#94a3b8">Hipotenusa</text>
        </svg>
      );

    case 'angulo_30':
    case 'angulo_60':
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <circle cx="100" cy="60" r="42" stroke="#00f0ff" strokeWidth="2" fill="#00f0ff" fillOpacity="0.05" />
          <line x1="50" y1="60" x2="150" y2="60" stroke="#334155" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1="100" y1="15" x2="100" y2="105" stroke="#334155" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1="100" y1="60" x2="135" y2="35" stroke="#ffbc00" strokeWidth="2.5" />
          <text x="110" y="53" fontSize="11" fontWeight="bold" fill="#ffbc00">
            {type === 'angulo_30' ? '30°' : '60°'}
          </text>
          <text x="100" y="114" fontSize="9" textAnchor="middle" fill="#64748b" fontWeight="bold">CÍRCULO TRIGONOMÉTRICO</text>
        </svg>
      );

    case 'triangulo_calculo_5_10':
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <path d="M 30,95 L 160,95 L 160,25 Z" stroke="#00f0ff" strokeWidth="2.5" fill="#00f0ff" fillOpacity="0.1" />
          <text x="165" y="65" fontSize="12" fontWeight="bold" fill="#38bdf8">5 cm</text>
          <text x="75" y="50" fontSize="12" fontWeight="bold" fill="#ffbc00">10 cm</text>
          <text x="50" y="90" fontSize="11" fontWeight="bold" fill="#ffffff">α</text>
        </svg>
      );

    case 'triangulo_x_20':
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <path d="M 30,95 L 160,95 L 160,25 Z" stroke="#00f0ff" strokeWidth="2.5" fill="#00f0ff" fillOpacity="0.1" />
          <text x="165" y="65" fontSize="12" fontWeight="bold" fill="#f43f5e">x = ?</text>
          <text x="75" y="50" fontSize="12" fontWeight="bold" fill="#ffbc00">20 cm</text>
          <text x="50" y="90" fontSize="11" fontWeight="bold" fill="#38bdf8">30°</text>
        </svg>
      );

    case 'triangulo_45':
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <path d="M 40,95 L 140,95 L 140,20 Z" stroke="#00f0ff" strokeWidth="2.5" fill="#00f0ff" fillOpacity="0.1" />
          <text x="55" y="90" fontSize="11" fontWeight="bold" fill="#ffbc00">45°</text>
          <text x="75" y="112" fontSize="9" fill="#94a3b8" fontWeight="bold">Cateto A = L</text>
          <text x="145" y="60" fontSize="9" fill="#94a3b8" fontWeight="bold">Cateto O = L</text>
        </svg>
      );

    case 'predio_30m':
    case 'torre_sombra_45':
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <rect x="140" y="20" width="30" height="75" fill="#1e293b" stroke="#38bdf8" strokeWidth="1.5" rx="3" />
          <path d="M 25,95 L 140,95 L 140,20 Z" stroke="#ffbc00" strokeWidth="2.5" strokeDasharray="4 4" />
          <text x="65" y="112" fontSize="10" fontWeight="bold" fill="#38bdf8">Distância: 30 m</text>
          <text x="145" y="60" fontSize="11" fontWeight="bold" fill="#ffbc00" transform="rotate(-90,145,60)">Altura (h)</text>
          <text x="45" y="90" fontSize="11" fontWeight="bold" fill="#00f0ff">45°</text>
        </svg>
      );

    case 'triangulo_cossenos_5_8':
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <path d="M 30,95 L 170,95 L 120,30 Z" stroke="#00f0ff" strokeWidth="2.5" fill="#00f0ff" fillOpacity="0.1" />
          <text x="60" y="55" fontSize="11" fontWeight="bold" fill="#38bdf8">c = 8</text>
          <text x="150" y="55" fontSize="11" fontWeight="bold" fill="#38bdf8">b = 5</text>
          <text x="95" y="112" fontSize="12" fontWeight="bold" fill="#f43f5e">a = ?</text>
          <text x="45" y="90" fontSize="10" fontWeight="bold" fill="#ffbc00">60°</text>
        </svg>
      );

    default:
      return (
        <svg className={className} viewBox="0 0 200 120" fill="none">
          <rect width="200" height="120" rx="12" fill="#070c1a" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
          <path d="M 30,95 L 160,95 L 30,25 Z" stroke="#00f0ff" strokeWidth="2.5" fill="#00f0ff" fillOpacity="0.1" />
          <rect x="30" y="80" width="15" height="15" stroke="#38bdf8" strokeWidth="1.5" fill="none" />
          <text x="90" y="112" fontSize="10" fontWeight="bold" fill="#38bdf8">Cateto (b)</text>
          <text x="12" y="65" fontSize="10" fontWeight="bold" fill="#38bdf8" transform="rotate(-90,12,65)">Cateto (a)</text>
          <text x="95" y="55" fontSize="11" fontWeight="bold" fill="#ffbc00">Hipotenusa (c)</text>
        </svg>
      );
  }
};
