import React from 'react';
import { BookOpen, Calculator } from 'lucide-react';

export const SupportMaterialsTab: React.FC = () => {
  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-[#0b1329]/90 border border-cyan-500/30 text-white p-6 sm:p-8 rounded-3xl shadow-[0_0_25px_rgba(0,240,255,0.15)] backdrop-blur-xl flex items-center justify-between">
        <div className="space-y-2">
          <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-black px-3.5 py-1 rounded-full uppercase tracking-wider inline-block">
            Guia Pedagógico Holográfico
          </span>
          <h2 className="text-2xl sm:text-3xl font-black flex items-center gap-2.5">
            <BookOpen className="w-8 h-8 text-amber-300" /> Materiais de Apoio & Fórmulas
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm max-w-xl">
            Revise as fórmulas essenciais, critérios de semelhança e a tabela de ângulos notáveis para aprimorar sua investigação!
          </p>
        </div>
      </div>

      {/* Main Formulas Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pitágoras - AMARELO / DOURADO */}
        <div className="bg-gradient-to-br from-[#1c1303]/95 via-[#0b0802]/95 to-[#160f02]/95 p-6 sm:p-7 rounded-3xl border-2 border-amber-400/70 shadow-[0_0_25px_rgba(251,191,36,0.2)] space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-yellow-500 text-slate-950 rounded-2xl flex items-center justify-center font-black text-xl shadow-[0_0_15px_rgba(251,191,36,0.8)]">
              📐
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-amber-200">Teorema de Pitágoras</h3>
              <span className="text-xs text-amber-300 font-bold bg-amber-950/80 border border-amber-400/50 px-2 py-0.5 rounded-full inline-block mt-0.5">
                Exclusivo para triângulos retângulos
              </span>
            </div>
          </div>

          <div className="bg-[#080501] p-4 rounded-2xl text-center font-mono font-black text-xl text-[#FFEA00] border-2 border-amber-400/60 shadow-[0_0_15px_rgba(251,191,36,0.25)]">
            c² = a² + b²
          </div>

          <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed">
            O quadrado da hipotenusa (c, lado oposto ao ângulo reto de 90°) equivale à soma dos quadrados dos catetos (a e b). Ternos pitagóricos comuns: (3, 4, 5), (5, 12, 13) e (8, 15, 17).
          </p>
        </div>

        {/* Lei dos Senos - CIANO */}
        <div className="bg-gradient-to-br from-[#021824]/95 via-[#010c14]/95 to-[#032030]/95 p-6 sm:p-7 rounded-3xl border-2 border-cyan-400/70 shadow-[0_0_25px_rgba(0,240,255,0.2)] space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-sky-500 text-slate-950 rounded-2xl flex items-center justify-center font-black text-xl shadow-[0_0_15px_rgba(0,240,255,0.8)]">
              📏
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-cyan-200">Lei dos Senos</h3>
              <span className="text-xs text-cyan-300 font-bold bg-cyan-950/80 border border-cyan-400/50 px-2 py-0.5 rounded-full inline-block mt-0.5">
                Triângulos genéricos (com 2 ângulos e 1 lado)
              </span>
            </div>
          </div>

          <div className="bg-[#010910] p-4 rounded-2xl text-center font-mono font-black text-lg text-cyan-200 border-2 border-cyan-400/60 shadow-[0_0_15px_rgba(0,240,255,0.25)]">
            a / sen(A) = b / sen(B) = c / sen(C) = 2R
          </div>

          <p className="text-xs sm:text-sm text-cyan-100/90 leading-relaxed">
            Em qualquer triângulo plano, os lados são diretamente proporcionais aos senos dos ângulos opostos. A razão constante de proporcionalidade é igual a 2R (diâmetro do círculo circunscrito).
          </p>
        </div>

        {/* Lei dos Cossenos - ROSA */}
        <div className="bg-gradient-to-br from-[#240310]/95 via-[#120108]/95 to-[#2a0414]/95 p-6 sm:p-7 rounded-3xl border-2 border-rose-400/70 shadow-[0_0_25px_rgba(244,63,94,0.2)] space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-rose-400 to-pink-500 text-slate-950 rounded-2xl flex items-center justify-center font-black text-xl shadow-[0_0_15px_rgba(244,63,94,0.8)]">
              📊
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-rose-200">Lei dos Cossenos</h3>
              <span className="text-xs text-rose-300 font-bold bg-rose-950/80 border border-rose-400/50 px-2 py-0.5 rounded-full inline-block mt-0.5">
                Dois lados e o ângulo entre eles
              </span>
            </div>
          </div>

          <div className="bg-[#100106] p-4 rounded-2xl text-center font-mono font-black text-lg text-rose-200 border-2 border-rose-400/60 shadow-[0_0_15px_rgba(244,63,94,0.25)]">
            a² = b² + c² - 2bc · cos(A)
          </div>

          <p className="text-xs sm:text-sm text-rose-100/90 leading-relaxed">
            Generalização do Teorema de Pitágoras. Quando A = 90°, cos(90°) = 0, reduzindo a a² = b² + c². Quando A &gt; 90° (obtuso), cos(A) é negativo, tornando o termo -2bc·cos(A) positivo!
          </p>
        </div>

        {/* Relações de Semelhança - ESMERALDA */}
        <div className="bg-gradient-to-br from-[#021f12]/95 via-[#010e08]/95 to-[#032717]/95 p-6 sm:p-7 rounded-3xl border-2 border-emerald-400/70 shadow-[0_0_25px_rgba(16,185,129,0.2)] space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-teal-400 text-slate-950 rounded-xl flex items-center justify-center font-black text-xl shadow-[0_0_15px_rgba(16,185,129,0.8)]">
              🔺
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-emerald-200">Relações de Semelhança</h3>
              <span className="text-xs text-emerald-300 font-bold bg-emerald-950/80 border border-emerald-400/50 px-2 py-0.5 rounded-full inline-block mt-0.5">
                Critérios AA, LLL e razão de áreas
              </span>
            </div>
          </div>

          <div className="bg-[#010e07] p-4 rounded-2xl text-center font-mono font-black text-lg text-emerald-200 border-2 border-emerald-400/60 shadow-[0_0_15px_rgba(16,185,129,0.25)]">
            Lados: k | Perímetros: k | Áreas: k²
          </div>

          <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
            Se dois triângulos possuem mesma forma (ângulos congruentes) e razão linear k, seus perímetros variam na mesma razão k, enquanto suas áreas variam no quadrado da razão (k²).
          </p>
        </div>
      </div>

      {/* Tabela de Ângulos Notáveis */}
      <div className="bg-[#0b1329]/80 backdrop-blur-xl p-6 sm:p-8 rounded-3xl shadow-xl border border-cyan-500/30 space-y-4">
        <h3 className="text-xl font-black text-white flex items-center gap-2">
          <Calculator className="w-5 h-5 text-cyan-400" /> Tabela de Ângulos Notáveis (Trigonometria)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-center border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="bg-[#060a16] text-cyan-300 font-extrabold border-b border-cyan-500/30">
                <th className="py-3 px-4 text-left">Função Trigonométrica</th>
                <th className="py-3 px-4">30° (π/6)</th>
                <th className="py-3 px-4">45° (π/4)</th>
                <th className="py-3 px-4">60° (π/3)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cyan-500/10">
              <tr>
                <td className="py-3 px-4 text-left font-bold text-white">Seno (sen)</td>
                <td className="py-3 px-4 font-mono font-bold text-amber-300">1/2 = 0,5</td>
                <td className="py-3 px-4 font-mono font-bold text-amber-300">√2 / 2 ≈ 0,707</td>
                <td className="py-3 px-4 font-mono font-bold text-amber-300">√3 / 2 ≈ 0,866</td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-left font-bold text-white">Cosseno (cos)</td>
                <td className="py-3 px-4 font-mono font-bold text-cyan-300">√3 / 2 ≈ 0,866</td>
                <td className="py-3 px-4 font-mono font-bold text-cyan-300">√2 / 2 ≈ 0,707</td>
                <td className="py-3 px-4 font-mono font-bold text-cyan-300">1/2 = 0,5</td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-left font-bold text-white">Tangente (tan)</td>
                <td className="py-3 px-4 font-mono font-bold text-emerald-300">√3 / 3 ≈ 0,577</td>
                <td className="py-3 px-4 font-mono font-bold text-emerald-300">1</td>
                <td className="py-3 px-4 font-mono font-bold text-emerald-300">√3 ≈ 1,732</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
