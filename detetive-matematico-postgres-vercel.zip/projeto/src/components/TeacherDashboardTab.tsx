import React, { useState, useMemo } from 'react';
import { User, QuestionAttempt, ChallengeReport } from '../types';
import { Storage, INITIAL_SERIES } from '../utils/storage';
import { StudentDetailModal } from './StudentDetailModal';
import {
  Users,
  AlertTriangle,
  Clock,
  Filter,
  BarChart3,
  Search,
  Eye,
  GraduationCap,
  Sparkles,
  BookOpen,
  Lock
  , MessageSquareWarning
} from 'lucide-react';

interface TeacherDashboardTabProps {
  currentUser: User | null;
  onOpenAuth: () => void;
}

export const TeacherDashboardTab: React.FC<TeacherDashboardTabProps> = ({
  currentUser,
  onOpenAuth
}) => {
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('todos');
  const [searchStudent, setSearchStudent] = useState<string>('');

  // Modal inspection state
  const [selectedStudentForModal, setSelectedStudentForModal] = useState<{
    nome: string;
    serie: string;
    tentativas: QuestionAttempt[];
  } | null>(null);

  // Strictly check if current logged in user is a teacher (NO DEMO OPTION as requested)
  const isTeacher = currentUser?.tipo === 'professor';

  const [version, setVersion] = useState(0);

  // Acompanha as atualizações do banco de dados PostgreSQL
  React.useEffect(() => {
    const unsubscribe = Storage.subscribe(() => {
      setVersion((v) => v + 1);
    });
    return unsubscribe;
  }, []);

  // Retrieve teacher analytics from persistent storage
  const studentAnalytics = useMemo(() => {
    return Storage.getTeacherStudentAnalytics(selectedClassFilter);
  }, [selectedClassFilter, version]);

  const themeOverview = useMemo(() => {
    return Storage.getTeacherThemeOverview(selectedClassFilter);
  }, [selectedClassFilter, version]);

  const filteredStudents = useMemo(() => {
    if (!searchStudent.trim()) return studentAnalytics;
    const q = searchStudent.toLowerCase();
    return studentAnalytics.filter(
      (s) => s.nome.toLowerCase().includes(q) || s.serie.toLowerCase().includes(q)
    );
  }, [studentAnalytics, searchStudent]);

  const registeredTeachers = useMemo(() => {
    return Storage.getUsers().filter((u) => u.tipo === 'professor');
  }, [version]);

  const reports = useMemo(() => {
    return Storage.getReports()
      .filter((report) => selectedClassFilter === 'todos' || report.serie === selectedClassFilter)
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [selectedClassFilter, version]);

  const resolveReport = (report: ChallengeReport) => {
    Storage.saveReport({ ...report, status: report.status === 'aberto' ? 'resolvido' : 'aberto' });
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Detail Modal */}
      {selectedStudentForModal && (
        <StudentDetailModal
          isOpen={!!selectedStudentForModal}
          onClose={() => setSelectedStudentForModal(null)}
          studentName={selectedStudentForModal.nome}
          studentClass={selectedStudentForModal.serie}
          attempts={selectedStudentForModal.tentativas}
        />
      )}

      {/* Header Banner - Cyber Dark HUD */}
      <div className="bg-[#0b1329]/90 border border-cyan-500/30 text-white p-6 sm:p-8 rounded-3xl shadow-[0_0_25px_rgba(0,240,255,0.15)] backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center sm:text-left">
          <span className="bg-amber-500/20 text-amber-300 text-xs font-black px-3.5 py-1 rounded-full uppercase tracking-wider inline-block border border-amber-500/40 shadow-[0_0_10px_rgba(251,191,36,0.2)]">
            Módulo de Gestão Pedagógica
          </span>
          <h2 className="text-2xl sm:text-3xl font-black flex items-center justify-center sm:justify-start gap-2.5">
            <Users className="w-8 h-8 text-cyan-400" /> Painel Analítico dos Professores
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm max-w-xl">
            Acompanhe o <strong className="text-cyan-300">tempo exato que cada aluno dedicou às perguntas</strong> e diagnostique <strong className="text-rose-400">qual tema teve a maior taxa de erros</strong> para intervenções pedagógicas direcionadas.
          </p>
        </div>

        {isTeacher && (
          <div className="bg-[#060a16] px-5 py-3.5 rounded-2xl border border-cyan-500/40 text-center sm:text-right shrink-0 shadow-[0_0_15px_rgba(0,240,255,0.2)]">
            <span className="text-[11px] text-cyan-300 font-bold block uppercase tracking-wide">
              Docente Conectado
            </span>
            <span className="text-base sm:text-lg font-black text-amber-300">
              {currentUser?.nome || 'Profª Ariane Braz'}
            </span>
          </div>
        )}
      </div>

      {/* If not logged in as teacher: show teacher access prompt WITHOUT demo option */}
      {!isTeacher ? (
        <div className="space-y-6">
          <div className="bg-[#0b1329]/90 border border-amber-500/40 p-6 sm:p-8 rounded-3xl shadow-[0_0_20px_rgba(251,191,36,0.15)] flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mx-auto sm:mx-0">
                <Lock className="w-6 h-6 text-amber-400" />
              </div>
              <h4 className="font-black text-white text-lg flex items-center gap-2 justify-center sm:justify-start">
                <span>Área Restrita aos Professores</span>
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
                Para ter acesso às métricas detalhadas de tempo por pergunta e relatório de erros por tema de cada aluno, efetue login com sua conta docente institucional (@professor.educacao.sp.gov.br).
              </p>
            </div>

            <button
              onClick={onOpenAuth}
              className="bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-black px-6 py-3.5 rounded-2xl transition shadow-[0_0_20px_rgba(251,191,36,0.4)] text-xs sm:text-sm whitespace-nowrap shrink-0"
            >
              Fazer Login Docente
            </button>
          </div>

          {/* Faculty List */}
          <div className="bg-[#0b1329]/80 backdrop-blur-xl p-6 sm:p-8 rounded-3xl shadow-xl border border-cyan-500/30 space-y-4">
            <h3 className="text-xl font-black text-cyan-300 flex items-center gap-2">
              <Users className="w-5 h-5 text-cyan-400" /> Corpo Docente Cadastrado na Plataforma
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {registeredTeachers.map((prof) => (
                <div
                  key={prof.id}
                  className="p-4 bg-[#070b18] rounded-2xl border border-cyan-500/20 flex items-center gap-3 hover:border-cyan-400/50 transition shadow-sm"
                >
                  <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-500/40 text-cyan-300 flex items-center justify-center font-black text-lg shadow-sm">
                    {prof.nome.charAt(0)}
                  </div>
                  <div>
                    <h5 className="font-extrabold text-white text-sm">{prof.nome}</h5>
                    <span className="text-[11px] text-slate-400 font-mono block truncate max-w-[200px]">
                      {prof.email}
                    </span>
                    <span className="text-[10px] text-blue-300 bg-blue-500/20 border border-blue-400/50 shadow-[0_0_10px_rgba(59,130,246,0.3)] px-2.5 py-0.5 rounded-full font-bold inline-block mt-1">
                      Ministra: {prof.materia || 'Matemática'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* FULL TEACHER DASHBOARD CONTENT (WHEN TEACHER IS LOGGED IN) */
        <div className="space-y-8 animate-in fade-in duration-300">
          {/* Top Filter and Controls */}
          <div className="bg-[#0b1329]/80 backdrop-blur-xl p-5 rounded-3xl shadow-lg border border-cyan-500/30 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="w-full md:w-auto flex flex-col sm:flex-row items-start sm:items-center gap-2 flex-grow">
              <label className="text-xs font-black text-cyan-300 uppercase flex items-center gap-1.5 shrink-0">
                <Filter className="w-4 h-4 text-cyan-400" /> Filtrar Dados por Turma / Série:
              </label>
              <select
                value={selectedClassFilter}
                onChange={(e) => setSelectedClassFilter(e.target.value)}
                className="w-full sm:w-auto bg-[#070b18] border border-cyan-500/40 text-cyan-100 text-xs sm:text-sm font-bold rounded-2xl px-4 py-2.5 focus:ring-2 focus:ring-cyan-400 focus:outline-none cursor-pointer"
              >
                <option value="todos">Todas as Salas da Escola</option>
                {INITIAL_SERIES.map((serie) => (
                  <option key={serie} value={serie}>
                    {serie}
                  </option>
                ))}
              </select>
            </div>

            <div className="w-full md:w-72 relative">
              <Search className="w-4 h-4 text-cyan-400/60 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={searchStudent}
                onChange={(e) => setSearchStudent(e.target.value)}
                placeholder="Buscar aluno por nome..."
                className="w-full bg-[#070b18] border border-cyan-500/40 text-cyan-100 placeholder-slate-500 text-xs sm:text-sm rounded-2xl pl-10 pr-4 py-2.5 focus:ring-2 focus:ring-cyan-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="bg-[#0b1329]/80 backdrop-blur-xl rounded-3xl shadow-xl border border-rose-500/30 overflow-hidden">
            <div className="p-6 border-b border-rose-500/20 flex flex-wrap items-center justify-between gap-3">
              <div><h3 className="text-xl font-black text-white flex items-center gap-2"><MessageSquareWarning className="w-5 h-5 text-rose-400" /> Relatos de Erros dos Alunos</h3><p className="text-xs text-slate-400 mt-1">Problemas enviados nos cards de desafios para acompanhamento docente.</p></div>
              <span className="text-xs font-bold text-rose-300 bg-rose-950/40 border border-rose-500/40 px-3 py-1.5 rounded-full">{reports.filter((r) => r.status === 'aberto').length} aberto(s)</span>
            </div>
            {reports.length === 0 ? <div className="p-8 text-center text-slate-400 text-sm">Nenhum relato para esta turma.</div> : <div className="divide-y divide-rose-500/10">{reports.map((report) => <div key={report.id} className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-rose-950/10"><div className="space-y-1"><div className="flex flex-wrap items-center gap-2"><span className="font-black text-white">{report.desafioNome}</span><span className="text-[10px] px-2 py-0.5 rounded-full border border-cyan-500/30 text-cyan-300">{report.modo === 'oficial' ? 'Oficial' : 'Treine Mais'}</span><span className={`text-[10px] px-2 py-0.5 rounded-full border ${report.status === 'aberto' ? 'border-amber-500/40 text-amber-300 bg-amber-950/30' : 'border-emerald-500/40 text-emerald-300 bg-emerald-950/30'}`}>{report.status === 'aberto' ? 'Aberto' : 'Resolvido'}</span></div><p className="text-xs text-slate-300">{report.descricao}</p><p className="text-[11px] text-slate-500">{report.alunoNome} • {report.serie || 'Sem série'} • {report.data}</p></div><button type="button" onClick={() => resolveReport(report)} className="shrink-0 self-start lg:self-center px-3 py-2 rounded-xl border border-rose-500/40 text-rose-300 hover:bg-rose-950/40 font-bold text-xs cursor-pointer">{report.status === 'aberto' ? 'Marcar resolvido' : 'Reabrir relato'}</button></div>)}</div>}
          </div>

          {/* KEY ANALYTICS CARDS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* 1. Tema com Mais Erros */}
            <div className="bg-gradient-to-br from-rose-950/40 to-[#0b1329] p-6 rounded-3xl border-2 border-rose-500/40 shadow-[0_0_20px_rgba(244,63,94,0.15)] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-rose-300 uppercase tracking-wider">
                  Tema com Mais Erros
                </span>
                <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5" />
                </div>
              </div>
              <h3 className="text-xl font-black text-rose-200">
                {themeOverview.temaCriticoGeral}
              </h3>
              <p className="text-xs text-rose-300/80 leading-relaxed">
                Recomenda-se reforço pedagógico e retomada de exemplos práticos neste tema para a turma selecionada.
              </p>
            </div>

            {/* 2. Tempo Médio por Questão */}
            <div className="bg-gradient-to-br from-cyan-950/40 to-[#0b1329] p-6 rounded-3xl border-2 border-cyan-500/40 shadow-[0_0_20px_rgba(0,240,255,0.15)] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-cyan-300 uppercase tracking-wider">
                  Tempo Médio por Questão
                </span>
                <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
              </div>
              <h3 className="text-3xl font-black text-cyan-100 font-mono">
                {themeOverview.tempoMedioGeralEscola}s
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Média do tempo em segundos que os alunos permaneceram investigando antes de clicar em Confirmar Resposta.
              </p>
            </div>

            {/* 3. Total de Questões Resolvidas */}
            <div className="bg-gradient-to-br from-emerald-950/40 to-[#0b1329] p-6 rounded-3xl border-2 border-emerald-500/40 shadow-[0_0_20px_rgba(16,185,129,0.15)] space-y-2 sm:col-span-2 lg:col-span-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-emerald-300 uppercase tracking-wider">
                  Total de Resoluções
                </span>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
                  <BarChart3 className="w-5 h-5" />
                </div>
              </div>
              <h3 className="text-3xl font-black text-emerald-200 font-mono">
                {themeOverview.totalTentativasGeral}
              </h3>
              <p className="text-xs text-emerald-300/80 leading-relaxed">
                Tentativas monitoradas entre os Desafios Oficiais por Etapas e o módulo Treine Mais de Trigonometria.
              </p>
            </div>
          </div>

          {/* THEMES ERROR RATE BAR CHART & DIAGNOSTIC */}
          <div className="bg-[#0b1329]/80 backdrop-blur-xl p-6 sm:p-8 rounded-3xl shadow-xl border border-cyan-500/30 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-cyan-500/20 pb-4">
              <div>
                <h3 className="text-xl font-black text-white flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-cyan-400" /> Diagnóstico de Erros por Tema
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Percentual de erro calculado com base em todas as respostas dos alunos
                </p>
              </div>
              <span className="text-xs font-bold text-cyan-300 bg-cyan-950 px-3 py-1.5 rounded-full border border-cyan-500/40">
                {selectedClassFilter === 'todos' ? 'Toda a Escola' : selectedClassFilter}
              </span>
            </div>

            <div className="space-y-4">
              {themeOverview.temasStats.map((tema) => (
                <div key={tema.temaNome} className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs sm:text-sm">
                    <span className="font-extrabold text-slate-200 flex items-center gap-2">
                      <span className="text-cyan-400">📐</span> {tema.temaNome}
                      <span className="text-xs font-normal text-slate-400">
                        ({tema.totalErros} erros em {tema.totalRespostas} respostas • Tempo médio: {tema.tempoMedioSegundos}s)
                      </span>
                    </span>
                    <span
                      className={`font-black font-mono ${
                        tema.taxaErroPercentual >= 40
                          ? 'text-rose-400'
                          : tema.taxaErroPercentual >= 20
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {tema.taxaErroPercentual}% de erro
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-3 bg-[#060a16] rounded-full overflow-hidden flex border border-cyan-500/20">
                    <div
                      style={{ width: `${Math.min(100, Math.max(4, tema.taxaErroPercentual))}%` }}
                      className={`h-full rounded-full transition-all duration-500 ${
                        tema.taxaErroPercentual >= 40
                          ? 'bg-gradient-to-r from-rose-600 to-rose-400 shadow-[0_0_10px_rgba(244,63,94,0.6)]'
                          : tema.taxaErroPercentual >= 20
                          ? 'bg-gradient-to-r from-amber-600 to-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.6)]'
                          : 'bg-gradient-to-r from-emerald-600 to-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.6)]'
                      }`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* DETAILED STUDENT TABLE (TEMPO POR PERGUNTA E TEMA COM MAIS ERROS POR ALUNO) */}
          <div className="bg-[#0b1329]/80 backdrop-blur-xl rounded-3xl shadow-xl border border-cyan-500/30 overflow-hidden space-y-4">
            <div className="p-6 border-b border-cyan-500/20 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-xl font-black text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-cyan-400" /> Relatório por Aluno
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Visualize quanto tempo cada aluno ficou nas perguntas e qual tema ele teve mais erros
                </p>
              </div>
              <span className="text-xs font-bold text-cyan-300 bg-cyan-950 border border-cyan-500/40 px-3 py-1.5 rounded-full">
                {filteredStudents.length} aluno(s) listado(s)
              </span>
            </div>

            {filteredStudents.length === 0 ? (
              <div className="p-12 text-center text-slate-400 space-y-2">
                <Users className="w-12 h-12 text-slate-600 mx-auto" />
                <p className="text-base font-bold text-slate-300">Nenhum aluno encontrado para este filtro</p>
                <p className="text-xs text-slate-500">Altere o filtro de turma ou a busca por nome.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-[#070b18] text-cyan-300 font-extrabold uppercase text-[11px] border-b border-cyan-500/20">
                    <tr>
                      <th className="py-3.5 px-4 sm:px-6">Aluno</th>
                      <th className="py-3.5 px-4">Turma / Série</th>
                      <th className="py-3.5 px-4 text-center">Tempo Médio p/ Pergunta</th>
                      <th className="py-3.5 px-4">Tema com Mais Erros</th>
                      <th className="py-3.5 px-4 text-center">Acertos / Total</th>
                      <th className="py-3.5 px-4 sm:px-6 text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-cyan-500/10">
                    {filteredStudents.map((student) => (
                      <tr key={student.alunoId} className="hover:bg-cyan-950/30 transition">
                        {/* Name */}
                        <td className="py-4 px-4 sm:px-6">
                          <div className="font-extrabold text-white">
                            {student.nome}
                          </div>
                        </td>

                        {/* Class */}
                        <td className="py-4 px-4 text-slate-300 font-medium">
                          {student.serie}
                        </td>

                        {/* Average Time per Question */}
                        <td className="py-4 px-4 text-center font-mono font-bold text-cyan-300">
                          <span className="inline-flex items-center gap-1.5 bg-[#060a16] text-cyan-300 px-2.5 py-1 rounded-xl border border-cyan-500/40 text-xs">
                            <Clock className="w-3.5 h-3.5 text-cyan-400" />
                            {student.tempoMedioPorPergunta > 0 ? `${student.tempoMedioPorPergunta}s` : 'N/A'}
                          </span>
                        </td>

                        {/* Theme with most errors */}
                        <td className="py-4 px-4">
                          <span
                            className={`inline-block text-xs font-bold px-2.5 py-1 rounded-xl border ${
                              student.temaMaisErros.includes('erro')
                                ? 'bg-rose-950/60 text-rose-300 border-rose-500/40'
                                : student.totalPerguntas > 0
                                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                                : 'bg-slate-900 text-slate-400 border-slate-700'
                            }`}
                          >
                            {student.temaMaisErros}
                          </span>
                        </td>

                        {/* Accuracy */}
                        <td className="py-4 px-4 text-center font-mono font-bold">
                          <span className="text-emerald-400">{student.totalAcertos}</span> /{' '}
                          <span className="text-slate-400">{student.totalPerguntas}</span>
                        </td>

                        {/* Action: Open inspection modal */}
                        <td className="py-4 px-4 sm:px-6 text-right">
                          <button
                            onClick={() =>
                              setSelectedStudentForModal({
                                nome: student.nome,
                                serie: student.serie,
                                tentativas: student.tentativasDetalhes
                              })
                            }
                            className="bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 font-bold px-3.5 py-1.5 rounded-xl text-xs transition shadow-sm inline-flex items-center gap-1.5"
                          >
                            <Eye className="w-3.5 h-3.5" /> Detalhes
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Faculty Roster also displayed for authenticated teachers */}
          <div className="bg-[#0b1329]/80 backdrop-blur-xl p-6 sm:p-8 rounded-3xl shadow-xl border border-cyan-500/30 space-y-4">
            <h3 className="text-xl font-black text-cyan-300 flex items-center gap-2">
              <Users className="w-5 h-5 text-cyan-400" /> Corpo Docente Cadastrado na Plataforma
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {registeredTeachers.map((prof) => (
                <div
                  key={prof.id}
                  className="p-4 bg-[#070b18] rounded-2xl border border-cyan-500/20 flex items-center gap-3 hover:border-cyan-400/50 transition shadow-sm"
                >
                  <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-500/40 text-cyan-300 flex items-center justify-center font-black text-lg shadow-sm">
                    {prof.nome.charAt(0)}
                  </div>
                  <div>
                    <h5 className="font-extrabold text-white text-sm">{prof.nome}</h5>
                    <span className="text-[11px] text-slate-400 font-mono block truncate max-w-[200px]">
                      {prof.email}
                    </span>
                    <span className="text-[10px] text-blue-300 bg-blue-500/20 border border-blue-400/50 shadow-[0_0_10px_rgba(59,130,246,0.3)] px-2.5 py-0.5 rounded-full font-bold inline-block mt-1">
                      Ministra: {prof.materia || 'Matemática'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
