import React, { useEffect, useRef } from 'react';

interface MathParticleCelebrationProps {
  trigger: number; // Increment or set timestamp to fire explosion
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  glowColor: string;
  rotation: number;
  rotationSpeed: number;
  alpha: number;
  decay: number;
  type: 'triangle' | 'square' | 'circle' | 'symbol';
  symbol?: string;
}

const NEON_COLORS = [
  { fill: '#00F0FF', glow: 'rgba(0, 240, 255, 0.9)' }, // Electric Cyan
  { fill: '#10B981', glow: 'rgba(16, 185, 129, 0.9)' }, // Neon Emerald
  { fill: '#FFB800', glow: 'rgba(255, 184, 0, 0.9)' },  // Neon Gold
  { fill: '#FF2A85', glow: 'rgba(255, 42, 133, 0.9)' }, // Neon Hot Pink
  { fill: '#A855F7', glow: 'rgba(168, 85, 247, 0.9)' }, // Neon Purple
  { fill: '#38BDF8', glow: 'rgba(56, 189, 248, 0.9)' }, // Laser Sky
  { fill: '#FDE047', glow: 'rgba(253, 224, 71, 0.9)' }  // Bright Yellow
];

const MATH_SYMBOLS = ['Δ', 'θ', 'π', '√', 'Σ', 'x²', '90°', 'sen', 'cos', 'tg', '📐', '✦', '✨'];

export const MathParticleCelebration: React.FC<MathParticleCelebrationProps> = ({ trigger }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!trigger) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI displays
    const dpr = window.devicePixelRatio || 1;
    const width = window.innerWidth;
    const height = window.innerHeight;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.scale(dpr, dpr);

    // Origin: center-upper area of screen (near the challenge question card)
    const originX = width / 2;
    const originY = Math.max(120, height * 0.42);

    // Create 70-90 particles
    const particlesCount = 80;
    const particles: Particle[] = [];

    const types: ('triangle' | 'square' | 'circle' | 'symbol')[] = [
      'triangle',
      'triangle',
      'square',
      'circle',
      'symbol',
      'symbol'
    ];

    for (let i = 0; i < particlesCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 4 + Math.random() * 12;
      const upwardBias = -4 - Math.random() * 8; // Burst upwards like fireworks
      const colorObj = NEON_COLORS[Math.floor(Math.random() * NEON_COLORS.length)];
      const type = types[Math.floor(Math.random() * types.length)];
      const symbol = type === 'symbol' ? MATH_SYMBOLS[Math.floor(Math.random() * MATH_SYMBOLS.length)] : undefined;

      particles.push({
        x: originX + (Math.random() - 0.5) * 80,
        y: originY + (Math.random() - 0.5) * 40,
        vx: Math.cos(angle) * speed * 1.1,
        vy: Math.sin(angle) * speed + upwardBias,
        size: type === 'symbol' ? 14 + Math.random() * 12 : 6 + Math.random() * 10,
        color: colorObj.fill,
        glowColor: colorObj.glow,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.16,
        alpha: 1.0,
        decay: 0.008 + Math.random() * 0.012,
        type,
        symbol
      });
    }

    let animationFrameId: number;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      let aliveCount = 0;

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        if (p.alpha <= 0) continue;

        aliveCount++;

        // Physics updates
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.22; // Gravity
        p.vx *= 0.985; // Air resistance
        p.vy *= 0.985;
        p.rotation += p.rotationSpeed;
        p.alpha = Math.max(0, p.alpha - p.decay);

        // Render particle
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.globalAlpha = p.alpha;
        ctx.shadowBlur = 14;
        ctx.shadowColor = p.glowColor;

        if (p.type === 'triangle') {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          const r = p.size;
          ctx.moveTo(0, -r);
          ctx.lineTo((r * Math.sqrt(3)) / 2, r / 2);
          ctx.lineTo((-r * Math.sqrt(3)) / 2, r / 2);
          ctx.closePath();
          ctx.fill();
        } else if (p.type === 'square') {
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        } else if (p.type === 'circle') {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
          // Subtle neon outline ring
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.2;
          ctx.stroke();
        } else if (p.type === 'symbol' && p.symbol) {
          ctx.fillStyle = p.color;
          ctx.font = `bold ${p.size}px 'Oxanium', 'Orbitron', monospace, sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(p.symbol, 0, 0);
        }

        ctx.restore();
      }

      if (aliveCount > 0) {
        animationFrameId = requestAnimationFrame(render);
      } else {
        ctx.clearRect(0, 0, width, height);
      }
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (canvas && ctx) {
        ctx.clearRect(0, 0, width, height);
      }
    };
  }, [trigger]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-50 w-full h-full"
      style={{ pointerEvents: 'none' }}
      aria-hidden="true"
    />
  );
};
