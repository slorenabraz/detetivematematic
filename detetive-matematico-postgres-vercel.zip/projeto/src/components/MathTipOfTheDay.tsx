import React, { useState, useEffect } from 'react';
import { Lightbulb, Sparkles, RefreshCw, Compass, BookOpen, CheckCircle2 } from 'lucide-react';

export interface GeometricTip {
  id: number;
  categoria: string;
  icone: string;
  titulo: string;
  fato: string;
  aplicacaoPratica: string;
}

export const GEOMETRIC_TIPS: GeometricTip[] = [
  {
    id: 1,
    categoria: 'Geometria na Natureza',
    icone: '🐝',
    titulo: 'A Geometria Perfeita dos Favos de Mel',
    fato: 'As abelhas constroem seus favos em formato de prismas hexagonais porque o hexágono regular é a forma geométrica que possui o menor perímetro para a maior área no plano.',
    aplicacaoPratica: 'Isso permite armazenar a quantidade máxima de mel utilizando a menor quantidade possível de cera (Conjectura do Favo de Mel, comprovada pelo matemático Thomas Hales em 1999)!'
  },
  {
    id: 2,
    categoria: 'História da Matemática',
    icone: '📐',
    titulo: 'A Corda Sagrada dos Agrimensores do Antigo Egito',
    fato: 'Mais de 1.000 anos antes de Pitágoras formalizar seu teorema, os construtores das pirâmides egípcias utilizavam uma corda com 12 nós equidistantes formando um triângulo com lados 3, 4 e 5.',
    aplicacaoPratica: 'Como 3² + 4² = 5² (9 + 16 = 25), eles garantiam cantos e ângulos retos de exatamente 90° em fundações gigantescas sem precisar de transferidores!'
  },
  {
    id: 3,
    categoria: 'Poliedros e Topologia',
    icone: '🎲',
    titulo: 'A Relação Universal de Euler para Poliedros',
    fato: 'Para absolutamente qualquer poliedro convexo no espaço tridimensional (cubos, pirâmides, prismas ou dodecaedros), a relação entre vértices (V), arestas (A) e faces (F) é sempre constante.',
    aplicacaoPratica: 'A famosa fórmula V - A + F = 2 é uma das leis mais elegantes da topologia geométrica e se aplica desde cristais minerais até vírus icosaédricos!'
  },
  {
    id: 4,
    categoria: 'Curiosidades Topológicas',
    icone: '♾️',
    titulo: 'O Enigma da Fita de Möbius',
    fato: 'Se você pegar uma fita de papel, der meia-volta de 180° e unir as pontas, criará uma superfície que possui apenas UM lado e apenas UMA borda contínua.',
    aplicacaoPratica: 'Uma formiga caminhando ao longo da fita passará por todos os pontos sem nunca ter de pular ou cruzar uma borda externa!'
  },
  {
    id: 5,
    categoria: 'Proporções Áureas',
    icone: '✨',
    titulo: 'O Número de Ouro (Phi ≈ 1,618) e a Geometria',
    fato: 'A Razão Áurea surge da divisão de um segmento em duas partes tal que a razão entre a parte maior e a menor é idêntica à razão entre o total e a parte maior.',
    aplicacaoPratica: 'Essa proporção geométrica aparece na disposição das pétalas de girassóis, na espiral da concha do Náutilo e nas proporções clássicas do Partenon de Atenas.'
  },
  {
    id: 6,
    categoria: 'Geometria Espacial',
    icone: '🔷',
    titulo: 'Por que Existem Apenas 5 Sólidos Platônicos?',
    fato: 'Enquanto no plano bidimensional existem infinitos polígonos regulares, no espaço tridimensional só é matematicamente possível construir 5 poliedros regulares convexos.',
    aplicacaoPratica: 'São eles: Tetraedro (4 faces), Cubo (6 faces), Octaedro (8 faces), Dodecaedro (12 faces) e Icosaedro (20 faces), onde todas as faces e ângulos são idênticos.'
  },
  {
    id: 7,
    categoria: 'Fractais e Infinito',
    icone: '❄️',
    titulo: 'O Triângulo de Sierpinski: Área Zero e Perímetro Infinito',
    fato: 'Ao remover recursivamente o triângulo central invertido de um triângulo equilátero, cria-se o famoso fractal do Triângulo de Sierpinski.',
    aplicacaoPratica: 'Se o processo for repetido ao infinito, a área restante da figura aproxima-se de zero, mas a soma dos perímetros de todos os seus contornos tende ao infinito!'
  },
  {
    id: 8,
    categoria: 'Trigonometria e Astrometria',
    icone: '☀️',
    titulo: 'Como Tales de Mileto Mediu a Grande Pirâmide',
    fato: 'Tales usou a semelhança de triângulos e a trigonometria das sombras: ele fincou uma vara vertical no chão desértico e observou o movimento solar.',
    aplicacaoPratica: 'No instante exato em que o comprimento da sombra da vara era idêntico à altura da vara, a sombra da Grande Pirâmide também correspondia exatamente à sua altura real!'
  },
  {
    id: 9,
    categoria: 'Geometria Não-Euclidiana',
    icone: '🌐',
    titulo: 'Triângulos com Mais de 180° no Espaço Curvo',
    fato: 'No plano euclidiano escolar, a soma dos ângulos internos de qualquer triângulo é rigidamente 180°. Porém, sobre a superfície de uma esfera, isso muda completamente!',
    aplicacaoPratica: 'Desenhe um triângulo saindo do Polo Norte até o Equador, virando 90° para o leste e subindo de volta: a soma de seus três ângulos será de 270°!'
  },
  {
    id: 10,
    categoria: 'Constantes Geométricas',
    icone: '⭕',
    titulo: 'A Universalidade Cósmica do Número Pi (π)',
    fato: 'O número Pi (π ≈ 3,14159...) representa a razão imutável entre o perímetro de qualquer circunferência e o seu diâmetro, seja ela do tamanho de um próton ou de uma galáxia.',
    aplicacaoPratica: 'Sendo um número irracional e transcendente, suas casas decimais continuam indefinidamente sem nunca se repetirem em um padrão cíclico!'
  },
  {
    id: 11,
    categoria: 'Geometria dos Círculos',
    icone: '📐',
    titulo: 'O Teorema do Triângulo Inscrito no Diâmetro',
    fato: 'Qualquer triângulo desenhado dentro de uma circunferência onde um dos lados seja o próprio diâmetro é OBRIGATORIAMENTE um triângulo retângulo.',
    aplicacaoPratica: 'O ângulo inscrito oposto ao diâmetro medirá sempre 90°, uma propriedade fundamental descoberta por Tales de Mileto e amplamente usada em marcenaria e engenharia.'
  },
  {
    id: 12,
    categoria: 'Grafos e Cartografia',
    icone: '🗺️',
    titulo: 'O Teorema das Quatro Cores',
    fato: 'Qualquer mapa político sobre uma superfície plana ou esférica precisa de, no máximo, 4 cores distintas para garantir que nenhum país vizinho com fronteira comum compartilhe a mesma cor.',
    aplicacaoPratica: 'Proposto em 1852, foi o primeiro grande teorema da história da matemática a ser demonstrado com o auxílio fundamental de algoritmos de computador em 1976!'
  },
  {
    id: 13,
    categoria: 'Navegação e Curvatura',
    icone: '✈️',
    titulo: 'Geodésicas: Por que as Rotas Aéreas Parecem Curvas?',
    fato: 'Em mapas planos (como a projeção de Mercator), a rota de um avião entre Londres e Tóquio parece um arco curvado para cima em vez de uma linha reta horizontal.',
    aplicacaoPratica: 'Isso ocorre porque na superfície esférica da Terra, o menor caminho entre dois pontos é uma geodésica (um arco de grande círculo), e não a linha reta desenhada num mapa plano!'
  },
  {
    id: 14,
    categoria: 'Arquitetura e Engenharia',
    icone: '🏛️',
    titulo: 'A Catenária: O Segredo dos Arcos de Gaudí',
    fato: 'A curva natural descrita por uma corrente homogênea e flexível suspensa pelas extremidades sob a força da gravidade é chamada de catenária (função cosseno hiperbólico).',
    aplicacaoPratica: 'Quando invertida de cabeça para baixo, a catenária torna-se a estrutura autoportante mais resistente da física, usada por Antoni Gaudí nos arcos da Sagrada Família!'
  }
];

export const MathTipOfTheDay: React.FC = () => {
  const [currentTipIndex, setCurrentTipIndex] = useState<number>(0);
  const [isAnimating, setIsAnimating] = useState<boolean>(false);

  // Inicializa com uma dica aleatória no carregamento
  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * GEOMETRIC_TIPS.length);
    setCurrentTipIndex(randomIndex);
  }, []);

  const handleNextTip = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentTipIndex((prev) => {
        let nextIndex = Math.floor(Math.random() * GEOMETRIC_TIPS.length);
        if (nextIndex === prev) {
          nextIndex = (prev + 1) % GEOMETRIC_TIPS.length;
        }
        return nextIndex;
      });
      setIsAnimating(false);
    }, 180);
  };

  const tip = GEOMETRIC_TIPS[currentTipIndex] || GEOMETRIC_TIPS[0];

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#071329]/95 via-[#0b1b3d]/90 to-[#050c1e]/95 border-2 border-cyan-400/50 p-5 sm:p-7 shadow-[0_0_35px_rgba(0,240,255,0.18)] backdrop-blur-xl">
      {/* Luz ambiente holográfica */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Cabeçalho do Card */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-cyan-500/20 pb-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-cyan-950/80 border-2 border-cyan-400/60 flex items-center justify-center text-cyan-300 shadow-[0_0_15px_rgba(0,240,255,0.35)] shrink-0">
            <Lightbulb className="w-6 h-6 text-yellow-300 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40">
                Pista Investigativa #{tip.id}
              </span>
              <span className="text-[10px] font-bold text-amber-300 bg-amber-500/10 border border-amber-400/30 px-2 py-0.5 rounded-full">
                {tip.categoria}
              </span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white mt-0.5 flex items-center gap-2">
              <span>Dica Matemática do Dia</span>
              <Sparkles className="w-4 h-4 text-amber-400 inline" />
            </h3>
          </div>
        </div>

        {/* Botão Interativo para sortear nova dica */}
        <button
          type="button"
          onClick={handleNextTip}
          className="self-start sm:self-auto bg-cyan-950/70 hover:bg-cyan-900/90 text-cyan-300 border border-cyan-400/60 hover:border-cyan-300 px-4 py-2 rounded-2xl text-xs font-black transition flex items-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.2)] cursor-pointer group"
          title="Sortear outra curiosidade geométrica"
        >
          <RefreshCw className={`w-3.5 h-3.5 transition-transform duration-500 ${isAnimating ? 'rotate-180' : 'group-hover:rotate-45'}`} />
          <span>Sortear Outra Dica</span>
        </button>
      </div>

      {/* Conteúdo da Dica com transição suave */}
      <div className={`mt-4 space-y-3.5 relative z-10 transition-opacity duration-200 ${isAnimating ? 'opacity-40 scale-98' : 'opacity-100 scale-100'}`}>
        <div className="flex items-start gap-3">
          <span className="text-3xl sm:text-4xl filter drop-shadow-[0_0_12px_rgba(0,240,255,0.6)] shrink-0 select-none">
            {tip.icone}
          </span>
          <div className="space-y-1.5 flex-1">
            <h4 className="text-base sm:text-lg font-black text-amber-300 drop-shadow-[0_0_10px_rgba(251,191,36,0.3)]">
              {tip.titulo}
            </h4>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
              {tip.fato}
            </p>
          </div>
        </div>

        {/* Box de Aplicação Prática / Investigação */}
        <div className="bg-[#040916]/80 border border-cyan-500/30 rounded-2xl p-3.5 flex items-start gap-3 shadow-inner">
          <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 shrink-0 mt-0.5">
            <CheckCircle2 className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xs text-cyan-100/90 leading-relaxed">
            <strong className="text-cyan-300 font-bold block mb-0.5">Aplicação no Raciocínio Geométrico:</strong>
            {tip.aplicacaoPratica}
          </div>
        </div>
      </div>
    </div>
  );
};
