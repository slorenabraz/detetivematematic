/**
 * Cliente HTTP da API do Detetive Matemático.
 *
 * Em produção (Vercel) a API fica na mesma origem do site (/api/...).
 * Em desenvolvimento o Vite faz proxy para http://localhost:3001.
 * Se necessário, defina VITE_API_BASE_URL para apontar para outro domínio.
 */
const RAW_BASE = ((import.meta.env.VITE_API_BASE_URL as string | undefined) || '').trim();

export const API_BASE = RAW_BASE.replace(/\/+$/, '');

export class ApiError extends Error {
  status: number;
  code?: string;

  constructor(status: number, message: string, code?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
  }
}

export interface ApiRequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: unknown;
  timeoutMs?: number;
}

function parseJson(texto: string): Record<string, unknown> {
  try {
    const valor = JSON.parse(texto) as unknown;
    return valor && typeof valor === 'object' ? (valor as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

export async function apiRequest<T = Record<string, unknown>>(
  path: string,
  options: ApiRequestOptions = {}
): Promise<T> {
  const { method = 'GET', body, timeoutMs = 15000 } = options;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(`${API_BASE}${path}`, {
      method,
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller.signal,
      cache: 'no-store'
    });

    const texto = await response.text();
    const dados = texto ? parseJson(texto) : {};

    if (!response.ok || dados.ok === false) {
      throw new ApiError(
        response.status,
        String(dados.error || dados.message || `Falha na comunicação com o servidor (${response.status}).`),
        typeof dados.code === 'string' ? dados.code : undefined
      );
    }

    return dados as T;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if ((error as Error)?.name === 'AbortError') {
      throw new ApiError(408, 'Tempo esgotado ao falar com o servidor.', 'TIMEOUT');
    }
    throw new ApiError(
      0,
      error instanceof Error ? error.message : 'Sem conexão com o servidor.',
      'NETWORK_ERROR'
    );
  } finally {
    clearTimeout(timer);
  }
}

/** Mensagem amigável para qualquer erro de API/rede. */
export function mensagemDeErro(error: unknown): string {
  if (error instanceof ApiError) return error.message;
  if (error instanceof Error) return error.message;
  return String(error);
}

/** Erro de rede / banco indisponível (permite continuar no modo local). */
export function erroDeInfraestrutura(error: unknown): boolean {
  if (!(error instanceof ApiError)) return true;
  return error.status === 0 || error.status === 408 || error.status === 503 || error.status >= 500;
}