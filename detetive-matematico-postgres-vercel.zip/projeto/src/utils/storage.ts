/**
 * Camada de dados do Detetive Matemático.
 *
 * Arquitetura:
 *  1. O banco PostgreSQL (via /api) é a fonte oficial dos dados.
 *  2. Todo o conteúdo é mantido em cache no navegador (localStorage), o que
 *     deixa ranking, histórico e painel do professor instantâneos e permite
 *     continuar funcionando mesmo sem internet.
 *  3. Toda escrita passa por uma fila de sincronização: se a conexão falhar,
 *     o registro fica guardado e é enviado automaticamente depois.
 *  4. Se a plataforma for publicada sem banco configurado, o aplicativo
 *     continua 100% funcional em MODO LOCAL.
 *
 * A API pública deste módulo é a mesma usada pelos componentes da interface.
 */
import { User, QuestionAttempt, SessionResult, ChallengeReport, TeacherThemeStats } from '../types';
import { ApiError, apiRequest, erroDeInfraestrutura, mensagemDeErro } from './api';
import { decodificarCredencialGoogle } from './google';

export const INITIAL_SERIES = [
  '6º Ano Fundamental',
  '7º Ano Fundamental',
  '8º Ano Fundamental',
  '9º Ano Fundamental',
  '1º Ano Ensino Médio',
  '2º Ano Ensino Médio',
  '3º Ano Ensino Médio'
];

/** Conta docente criada automaticamente (no banco e no modo local). */
export const DEFAULT_TEACHER: User = {
  id: 'prof-ariane-braz',
  nome: 'Profª Ariane Braz',
  tipo: 'professor',
  email: 'arianebraz3@gmail.com',
  senha: '123',
  serie: 'Corpo Docente',
  materia: 'Matemática e Geometria',
  dataCadastro: new Date().toLocaleDateString('pt-BR')
};

const STORAGE_KEYS = {
  USERS: 'detetive_db_usuarios',
  SESSION_USER: 'detetive_session_user',
  RESULTS: 'detetive_db_resultados',
  ATTEMPTS: 'detetive_db_attempts',
  REPORTS: 'detetive_db_reports',
  QUEUE: 'detetive_db_fila_sincronizacao',
  META: 'detetive_db_meta_v2'
};

export type SyncMode = 'connecting' | 'cloud' | 'local';

export interface SyncStatus {
  connected: boolean;
  syncing: boolean;
  userCount: number;
  resultCount: number;
  attemptCount: number;
  mode: SyncMode;
  pending: number;
  lastSyncAt: number;
  lastError: string;
  message: string;
}

export interface LoginResult {
  ok: boolean;
  user?: User;
  error?: string;
}

export interface RegisterInput {
  nome: string;
  tipo: 'aluno' | 'professor';
  email: string;
  senha: string;
  serie?: string;
  materia?: string;
}

type Listener = () => void;

type QueueOp = {
  id: string;
  tipo: 'user' | 'result' | 'attempt' | 'report';
  payload: unknown;
  criadoEm: number;
};

/* -------------------------------------------------------------------------- */
/* Estado interno                                                              */
/* -------------------------------------------------------------------------- */

const listeners = new Set<Listener>();

let users: User[] = [];
let results: SessionResult[] = [];
let attempts: QuestionAttempt[] = [];
let reports: ChallengeReport[] = [];
let fila: QueueOp[] = [];

let mode: SyncMode = 'connecting';
let connected = false;
let syncing = false;
let lastSyncAt = 0;
let lastError = '';
let iniciado = false;
let ultimaTentativaConexao = 0;
let timer: number | null = null;

const INTERVALO_SINCRONIZACAO_MS = 15000;
const INTERVALO_RETENTATIVA_LOCAL_MS = 30000;

function notify(): void {
  listeners.forEach((fn) => {
    try {
      fn();
    } catch (error) {
      console.error('[storage] erro em listener de sincronização:', error);
    }
  });
}

function uid(prefixo: string): string {
  return `${prefixo}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function lerJSON<T>(chave: string, padrao: T): T {
  try {
    const bruto = localStorage.getItem(chave);
    if (!bruto) return padrao;
    const valor = JSON.parse(bruto) as T;
    return valor ?? padrao;
  } catch {
    return padrao;
  }
}

function salvarJSON(chave: string, valor: unknown): void {
  try {
    localStorage.setItem(chave, JSON.stringify(valor));
  } catch {
    /* navegador sem armazenamento disponível */
  }
}

function carregarCache(): void {
  users = lerJSON<User[]>(STORAGE_KEYS.USERS, []);
  results = lerJSON<SessionResult[]>(STORAGE_KEYS.RESULTS, []);
  attempts = lerJSON<QuestionAttempt[]>(STORAGE_KEYS.ATTEMPTS, []);
  reports = lerJSON<ChallengeReport[]>(STORAGE_KEYS.REPORTS, []);
  fila = lerJSON<QueueOp[]>(STORAGE_KEYS.QUEUE, []);
}

function persistirCache(): void {
  salvarJSON(STORAGE_KEYS.USERS, users);
  salvarJSON(STORAGE_KEYS.RESULTS, results);
  salvarJSON(STORAGE_KEYS.ATTEMPTS, attempts);
  salvarJSON(STORAGE_KEYS.REPORTS, reports);
}

function persistirFila(): void {
  salvarJSON(STORAGE_KEYS.QUEUE, fila);
}

function enfileirar(tipo: QueueOp['tipo'], payload: unknown): void {
  const identificador = (payload as { id?: string } | null)?.id;
  if (identificador) {
    // Substitui operação pendente do mesmo registro (mantém apenas a mais recente)
    fila = fila.filter((op) => (op.payload as { id?: string } | null)?.id !== identificador);
  }
  fila.push({ id: uid('op'), tipo, payload, criadoEm: Date.now() });
  persistirFila();
}

function payloadUsuario(user: User) {
  return {
    id: user.id,
    nome: user.nome,
    tipo: user.tipo,
    email: user.email,
    senha: user.senha || '',
    serie: user.serie || '',
    materia: user.materia || '',
    dataCadastro: user.dataCadastro || new Date().toLocaleDateString('pt-BR')
  };
}

function upsertUsuarioLocal(user: User): void {
  const indice = users.findIndex(
    (u) => u.id === user.id || u.email.toLowerCase() === user.email.toLowerCase()
  );
  if (indice >= 0) {
    users[indice] = { ...users[indice], ...user };
  } else {
    users.push(user);
  }
}

/* -------------------------------------------------------------------------- */
/* Sincronização com o banco de dados                                          */
/* -------------------------------------------------------------------------- */

interface RespostaData {
  users?: User[];
  results?: SessionResult[];
  attempts?: QuestionAttempt[];
  reports?: ChallengeReport[];
  counts?: { users: number; results: number; attempts: number };
}

function mesclarRemoto<T extends { id: string }>(remoto: T[], local: T[]): T[] {
  const pendentes = new Set(
    fila.map((op) => (op.payload as { id?: string } | null)?.id).filter(Boolean) as string[]
  );
  const mapa = new Map<string, T>();
  remoto.forEach((item) => mapa.set(item.id, item));
  local.forEach((item) => {
    if (pendentes.has(item.id) && !mapa.has(item.id)) mapa.set(item.id, item);
  });
  return Array.from(mapa.values());
}

async function puxarDados(): Promise<void> {
  const dados = await apiRequest<RespostaData>('/api/data', { timeoutMs: 20000 });
  users = mesclarRemoto(Array.isArray(dados.users) ? dados.users : [], users);
  results = mesclarRemoto(Array.isArray(dados.results) ? dados.results : [], results);
  attempts = mesclarRemoto(Array.isArray(dados.attempts) ? dados.attempts : [], attempts);
  reports = mesclarRemoto(Array.isArray(dados.reports) ? dados.reports : [], reports);
  persistirCache();
}

/** Envia ao banco tudo o que existe apenas no navegador (primeira migração). */
function enfileirarDadosLocais(): void {
  users.forEach((user) => enfileirar('user', payloadUsuario(user)));
  results.forEach((result) => enfileirar('result', result));
  attempts.forEach((attempt) => enfileirar('attempt', attempt));
  reports.forEach((report) => enfileirar('report', report));
}

async function enviarFila(): Promise<void> {
  if (mode !== 'cloud' || !connected || fila.length === 0) return;

  syncing = true;
  notify();

  for (const op of [...fila]) {
    try {
      if (op.tipo === 'user') {
        await apiRequest('/api/users', { method: 'POST', body: op.payload });
      } else if (op.tipo === 'result') {
        await apiRequest('/api/results', { method: 'POST', body: op.payload });
      } else {
        await apiRequest(op.tipo === 'report' ? '/api/reports' : '/api/attempts', { method: 'POST', body: op.payload });
      }
      fila = fila.filter((item) => item.id !== op.id);
      persistirFila();
    } catch (error) {
      lastError = mensagemDeErro(error);
      if (erroDeInfraestrutura(error)) connected = false;
      break;
    }
  }

  syncing = false;
  notify();
}

function definirModoLocal(motivo: string): void {
  const eraNuvem = mode === 'cloud';
  mode = 'local';
  connected = false;
  syncing = false;
  lastError = motivo;
  persistirCache();
  if (eraNuvem) console.warn('[storage] passando para o modo local:', motivo);
  notify();
}

async function conectar(): Promise<void> {
  ultimaTentativaConexao = Date.now();

  try {
    const saude = await apiRequest<{ database: boolean; configured: boolean }>('/api/health', {
      timeoutMs: 8000
    });

    if (!saude.database) {
      definirModoLocal(
        saude.configured
          ? 'Banco configurado, mas inacessível no momento. Os dados continuam salvos neste navegador.'
          : 'Modo local: defina a variável DATABASE_URL (Vercel) para guardar os dados no banco PostgreSQL.'
      );
      return;
    }

    // Verifica se o banco está vazio e se já existem dados somente no navegador
    const dados = await apiRequest<RespostaData>('/api/data', { timeoutMs: 20000 });
    const contagens = dados.counts || { users: 0, results: 0, attempts: 0 };
    const bancoVazio = contagens.users === 0 && contagens.results === 0 && contagens.attempts === 0;
    const temDadosLocais = users.length + results.length + attempts.length > 0;

    if (bancoVazio && temDadosLocais) {
      console.info('[storage] banco vazio: migrando os dados salvos neste navegador...');
      enfileirarDadosLocais();
    }

    users = mesclarRemoto(Array.isArray(dados.users) ? dados.users : [], users);
    results = mesclarRemoto(Array.isArray(dados.results) ? dados.results : [], results);
    attempts = mesclarRemoto(Array.isArray(dados.attempts) ? dados.attempts : [], attempts);
    reports = mesclarRemoto(Array.isArray(dados.reports) ? dados.reports : [], reports);

    mode = 'cloud';
    connected = true;
    lastSyncAt = Date.now();
    lastError = '';
    persistirCache();
    notify();

    await enviarFila();
  } catch (error) {
    definirModoLocal(mensagemDeErro(error));
  }
}

/** Atualiza o cache com o banco (e reenvia pendências). */
export async function sincronizar(force = false): Promise<void> {
  if (mode === 'cloud' && connected) {
    await enviarFila();
    try {
      await puxarDados();
      connected = true;
      lastSyncAt = Date.now();
      lastError = '';
    } catch (error) {
      lastError = mensagemDeErro(error);
      if (erroDeInfraestrutura(error)) connected = false;
    }
    notify();
    return;
  }

  const espera = force ? 0 : INTERVALO_RETENTATIVA_LOCAL_MS;
  if (Date.now() - ultimaTentativaConexao >= espera) await conectar();
}

/** Inicia a sincronização automática (chamado uma vez ao carregar o app). */
export function initSync(): void {
  if (iniciado) return;
  iniciado = true;

  carregarCache();
  notify();

  void conectar();

  if (typeof window !== 'undefined') {
    timer = window.setInterval(() => {
      if (document.visibilityState === 'visible') void sincronizar();
    }, INTERVALO_SINCRONIZACAO_MS);

    window.addEventListener('focus', () => void sincronizar());
    window.addEventListener('online', () => void sincronizar(true));
  }
}

/* -------------------------------------------------------------------------- */
/* API pública                                                                 */
/* -------------------------------------------------------------------------- */

export const Storage = {
  subscribe(listener: Listener): () => void {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },

  getSyncStatus(): SyncStatus {
    return {
      connected,
      syncing,
      userCount: users.length,
      resultCount: results.length,
      attemptCount: attempts.length,
      mode,
      pending: fila.length,
      lastSyncAt,
      lastError,
      message:
        mode === 'cloud'
          ? connected
            ? 'Sincronizado'
            : 'Reconectando...'
          : 'Modo local (dados salvos neste navegador)'
    };
  },

  /** 'cloud' = banco PostgreSQL ativo; 'local' = apenas neste navegador. */
  getMode(): SyncMode {
    return mode;
  },

  isCloudMode(): boolean {
    return mode === 'cloud' && connected;
  },

  getPendingCount(): number {
    return fila.length;
  },

  sincronizar,

  /* ------------------------------- Usuários ------------------------------- */

  getUsers(): User[] {
    return users;
  },

  getUserById(id: string): User | undefined {
    if (!id) return undefined;
    const limpo = id.trim().toLowerCase();
    return users.find((u) => u.id.toLowerCase() === limpo || u.email.toLowerCase() === limpo);
  },

  saveUser(user: User): void {
    upsertUsuarioLocal(user);
    persistirCache();
    notify();
    enfileirar('user', payloadUsuario(user));
    void enviarFila();
  },

  /** Cria a conta de um aluno ou professor (banco de dados quando disponível). */
  async register(dados: RegisterInput): Promise<LoginResult> {
    const nome = dados.nome.trim();
    const email = dados.email.trim();

    if (mode === 'cloud' && connected) {
      try {
        const resposta = await apiRequest<{ user: User }>('/api/auth/register', {
          method: 'POST',
          body: {
            nome,
            email,
            senha: dados.senha,
            tipo: dados.tipo,
            serie: dados.serie,
            materia: dados.materia
          }
        });
        if (resposta.user) {
          upsertUsuarioLocal({ ...resposta.user, senha: '' });
          persistirCache();
          notify();
          return { ok: true, user: resposta.user };
        }
      } catch (error) {
        if (!erroDeInfraestrutura(error)) {
          return { ok: false, error: mensagemDeErro(error) };
        }
        lastError = mensagemDeErro(error);
        connected = false;
      }
    }

    const normalizado = email.toLowerCase();
    if (
      users.some(
        (u) => u.email.toLowerCase() === normalizado || u.id.toLowerCase() === normalizado
      )
    ) {
      return {
        ok: false,
        error: 'Atenção: Este e-mail ou usuário de acesso já está cadastrado.'
      };
    }

    const novoUsuario: User = {
      id: uid('usr'),
      nome,
      tipo: dados.tipo,
      email,
      senha: dados.senha,
      serie: dados.tipo === 'aluno' ? dados.serie || INITIAL_SERIES[3] : 'Corpo Docente',
      materia: dados.tipo === 'professor' ? dados.materia || 'Matemática' : undefined,
      dataCadastro: new Date().toLocaleDateString('pt-BR')
    };

    Storage.saveUser(novoUsuario);
    return { ok: true, user: novoUsuario };
  },

  /** Autentica o usuário (banco de dados quando disponível; modo local como reserva). */
  async login(login: string, senha: string, tipo?: 'aluno' | 'professor'): Promise<LoginResult> {
    const identificador = login.trim().toLowerCase();

    if (mode === 'cloud' && connected) {
      try {
        const resposta = await apiRequest<{ user: User }>('/api/auth/login', {
          method: 'POST',
          body: { login: identificador, senha, tipo }
        });
        if (resposta.user) {
          upsertUsuarioLocal({ ...resposta.user, senha: '' });
          persistirCache();
          notify();
          return { ok: true, user: resposta.user };
        }
      } catch (error) {
        if (!erroDeInfraestrutura(error)) {
          return { ok: false, error: mensagemDeErro(error) };
        }
        lastError = mensagemDeErro(error);
        connected = false;
      }
    }

    const local = users.find(
      (u) =>
        (u.email.toLowerCase() === identificador || u.id.toLowerCase() === identificador) &&
        !!u.senha &&
        (u.senha === senha || u.senha.toLowerCase() === senha.toLowerCase())
    );

    if (local) return { ok: true, user: local };

    return { ok: false, error: 'E-mail/usuário ou senha incorretos. Verifique seus dados.' };
  },

  /** Redefine a senha a partir do e-mail/usuário cadastrado. */
  async resetPassword(login: string, novaSenha: string): Promise<LoginResult> {
    const identificador = login.trim().toLowerCase();

    if (mode === 'cloud' && connected) {
      try {
        const resposta = await apiRequest<{ user: User }>('/api/auth/reset-password', {
          method: 'POST',
          body: { login: identificador, novaSenha }
        });
        if (resposta.user) {
          upsertUsuarioLocal({ ...resposta.user, senha: '' });
          persistirCache();
          notify();
          return { ok: true, user: resposta.user };
        }
      } catch (error) {
        if (!erroDeInfraestrutura(error)) {
          return { ok: false, error: mensagemDeErro(error) };
        }
        lastError = mensagemDeErro(error);
        connected = false;
      }
    }

    const indice = users.findIndex(
      (u) => u.email.toLowerCase() === identificador || u.id.toLowerCase() === identificador
    );

    if (indice < 0) {
      return {
        ok: false,
        error: `E-mail ou usuário "${login}" não encontrado na plataforma. Verifique seus dados.`
      };
    }

    const atualizado: User = { ...users[indice], senha: novaSenha };
    users[indice] = atualizado;
    persistirCache();
    notify();
    enfileirar('user', payloadUsuario(atualizado));
    void enviarFila();

    return { ok: true, user: atualizado };
  },

  /** Compatibilidade com chamadas antigas (retorna true quando atualiza). */
  async updateUserPassword(id: string, novaSenha: string): Promise<boolean> {
    const resultado = await Storage.resetPassword(id, novaSenha);
    return resultado.ok;
  },

  /** Entrada com conta Google (valida o token no servidor). */
  async loginWithGoogle(credential: string, tipo?: 'aluno' | 'professor'): Promise<LoginResult> {
    if (mode === 'cloud' && connected) {
      try {
        const resposta = await apiRequest<{ user: User }>('/api/auth/google', {
          method: 'POST',
          body: { credential, tipo }
        });
        if (resposta.user) {
          upsertUsuarioLocal({ ...resposta.user, senha: '' });
          persistirCache();
          notify();
          return { ok: true, user: resposta.user };
        }
      } catch (error) {
        if (!erroDeInfraestrutura(error)) {
          return { ok: false, error: mensagemDeErro(error) };
        }
        lastError = mensagemDeErro(error);
        connected = false;
      }
    }

    const perfil = decodificarCredencialGoogle(credential);
    if (!perfil?.email) {
      return { ok: false, error: 'Não foi possível ler os dados da conta Google.' };
    }

    const existente = users.find(
      (u) => u.email.toLowerCase() === perfil.email.toLowerCase()
    );
    if (existente) return { ok: true, user: existente };

    const ehProfessor = tipo === 'professor' || perfil.email.toLowerCase() === DEFAULT_TEACHER.email.toLowerCase();
    const novoUsuario: User = {
      id: `google-${perfil.email.toLowerCase()}`,
      nome: perfil.nome || perfil.email,
      tipo: ehProfessor ? 'professor' : 'aluno',
      email: perfil.email,
      senha: '',
      serie: ehProfessor ? 'Corpo Docente' : INITIAL_SERIES[3],
      materia: ehProfessor ? 'Matemática e Geometria' : undefined,
      dataCadastro: new Date().toLocaleDateString('pt-BR')
    };

    Storage.saveUser(novoUsuario);
    return { ok: true, user: novoUsuario };
  },

  /* -------------------------------- Sessão -------------------------------- */

  getSessionUser(): User | null {
    return lerJSON<User | null>(STORAGE_KEYS.SESSION_USER, null);
  },

  setSessionUser(user: User | null): void {
    try {
      if (user) {
        localStorage.setItem(STORAGE_KEYS.SESSION_USER, JSON.stringify(user));
      } else {
        localStorage.removeItem(STORAGE_KEYS.SESSION_USER);
      }
    } catch {
      /* ignora */
    }
    notify();
  },

  /* ------------------------------- Resultados ----------------------------- */

  getResults(): SessionResult[] {
    return results;
  },

  saveResult(result: SessionResult): void {
    if (!results.some((item) => item.id === result.id)) {
      results.push(result);
    } else {
      results = results.map((item) => (item.id === result.id ? result : item));
    }
    persistirCache();
    notify();
    enfileirar('result', result);
    void enviarFila();
  },

  /* -------------------------------- Tentativas ---------------------------- */

  getAttempts(): QuestionAttempt[] {
    return attempts;
  },

  saveAttempt(attempt: QuestionAttempt): void {
    if (!attempts.some((item) => item.id === attempt.id)) {
      attempts.push(attempt);
    } else {
      attempts = attempts.map((item) => (item.id === attempt.id ? attempt : item));
    }
    persistirCache();
    notify();
    enfileirar('attempt', attempt);
    void enviarFila();
  },
  /* ----------------------------- Relatos de erro ------------------------- */
  getReports(): ChallengeReport[] {
    return reports;
  },
  saveReport(report: ChallengeReport): void {
    if (!reports.some((item) => item.id === report.id)) {
      reports.push(report);
    } else {
      reports = reports.map((item) => (item.id === report.id ? report : item));
    }
    persistirCache();
    notify();
    enfileirar('report', report);
    void enviarFila();
  },

  /* -------------------------------- Ranking ------------------------------- */

  getRanking(serieFilter?: string): {
    alunoId: string;
    nome: string;
    serie: string;
    totalAcertos: number;
    totalErros: number;
    desafiosConcluidos: number;
    tempoMedioSegundos: number;
    aproveitamento: number;
  }[] {
    const map = new Map<
      string,
      {
        alunoId: string;
        nome: string;
        serie: string;
        totalAcertos: number;
        totalErros: number;
        desafiosConcluidos: number;
        somaTempoSegundos: number;
        totalQuestoes: number;
      }
    >();

    results.forEach((r) => {
      if (serieFilter && serieFilter !== 'todos' && r.serie !== serieFilter) return;
      const atual = map.get(r.usuarioId) || {
        alunoId: r.usuarioId,
        nome: r.alunoNome,
        serie: r.serie,
        totalAcertos: 0,
        totalErros: 0,
        desafiosConcluidos: 0,
        somaTempoSegundos: 0,
        totalQuestoes: 0
      };
      atual.totalAcertos += r.acertos;
      atual.totalErros += r.erros;
      atual.desafiosConcluidos += 1;
      atual.somaTempoSegundos +=
        r.tempoTotalSegundos || (r.acertos + r.erros) * (r.tempoMedioPorQuestao || 25);
      atual.totalQuestoes += r.acertos + r.erros;
      map.set(r.usuarioId, atual);
    });

    return Array.from(map.values())
      .map((entrada) => {
        const total = entrada.totalAcertos + entrada.totalErros;
        return {
          alunoId: entrada.alunoId,
          nome: entrada.nome,
          serie: entrada.serie,
          totalAcertos: entrada.totalAcertos,
          totalErros: entrada.totalErros,
          desafiosConcluidos: entrada.desafiosConcluidos,
          tempoMedioSegundos:
            entrada.totalQuestoes > 0
              ? Math.round(entrada.somaTempoSegundos / entrada.totalQuestoes)
              : 0,
          aproveitamento: total > 0 ? Math.round((entrada.totalAcertos / total) * 100) : 0
        };
      })
      .sort((a, b) => {
        if (b.totalAcertos !== a.totalAcertos) return b.totalAcertos - a.totalAcertos;
        if (b.aproveitamento !== a.aproveitamento) return b.aproveitamento - a.aproveitamento;
        return a.tempoMedioSegundos - b.tempoMedioSegundos;
      });
  },

  /* ---------------------- Analytics do professor -------------------------- */

  getTeacherStudentAnalytics(serieFilter?: string): {
    alunoId: string;
    nome: string;
    serie: string;
    totalPerguntas: number;
    totalAcertos: number;
    totalErros: number;
    tempoMedioPorPergunta: number;
    temaMaisErros: string;
    tentativasDetalhes: QuestionAttempt[];
  }[] {
    const mapaAlunos = new Map<
      string,
      { alunoId: string; nome: string; serie: string; tentativas: QuestionAttempt[] }
    >();

    users
      .filter((u) => u.tipo === 'aluno')
      .forEach((u) => {
        if (serieFilter && serieFilter !== 'todos' && u.serie !== serieFilter) return;
        mapaAlunos.set(u.id, { alunoId: u.id, nome: u.nome, serie: u.serie, tentativas: [] });
      });

    attempts.forEach((attempt) => {
      if (serieFilter && serieFilter !== 'todos' && attempt.serie !== serieFilter) return;
      if (!mapaAlunos.has(attempt.usuarioId)) {
        mapaAlunos.set(attempt.usuarioId, {
          alunoId: attempt.usuarioId,
          nome: attempt.alunoNome,
          serie: attempt.serie,
          tentativas: []
        });
      }
      mapaAlunos.get(attempt.usuarioId)!.tentativas.push(attempt);
    });

    return Array.from(mapaAlunos.values())
      .map((aluno) => {
        const total = aluno.tentativas.length;
        const acertos = aluno.tentativas.filter((t) => t.acertou).length;
        const somaTempo = aluno.tentativas.reduce(
          (acc, cur) => acc + (cur.tempoGastoSegundos || 20),
          0
        );

        const errosPorTema: Record<string, number> = {};
        aluno.tentativas
          .filter((t) => !t.acertou)
          .forEach((t) => {
            errosPorTema[t.temaNome] = (errosPorTema[t.temaNome] || 0) + 1;
          });

        let temaMaisErros = 'Nenhum erro registrado';
        let maxErros = 0;
        Object.entries(errosPorTema).forEach(([tema, quantidade]) => {
          if (quantidade > maxErros) {
            maxErros = quantidade;
            temaMaisErros = `${tema} (${quantidade} erro${quantidade > 1 ? 's' : ''})`;
          }
        });

        return {
          alunoId: aluno.alunoId,
          nome: aluno.nome,
          serie: aluno.serie,
          totalPerguntas: total,
          totalAcertos: acertos,
          totalErros: total - acertos,
          tempoMedioPorPergunta: total > 0 ? Math.round(somaTempo / total) : 0,
          temaMaisErros:
            maxErros > 0
              ? temaMaisErros
              : total > 0
                ? 'Excelente! Zero erros'
                : 'Sem atividades registradas',
          tentativasDetalhes: aluno.tentativas.sort((a, b) => b.timestamp - a.timestamp)
        };
      })
      .sort((a, b) => b.totalPerguntas - a.totalPerguntas);
  },

  getTeacherThemeOverview(serieFilter?: string): {
    temasStats: TeacherThemeStats[];
    temaCriticoGeral: string;
    tempoMedioGeralEscola: number;
    totalTentativasGeral: number;
  } {
    const tentativas = attempts.filter((a) => {
      if (serieFilter && serieFilter !== 'todos') return a.serie === serieFilter;
      return true;
    });

    const themeMap: Record<string, { total: number; erros: number; tempoSoma: number }> = {
      'Teorema de Pitágoras': { total: 0, erros: 0, tempoSoma: 0 },
      'Lei dos Senos': { total: 0, erros: 0, tempoSoma: 0 },
      'Lei dos Cossenos': { total: 0, erros: 0, tempoSoma: 0 },
      'Relações de Semelhança': { total: 0, erros: 0, tempoSoma: 0 },
      'Trigonometria - Iniciante': { total: 0, erros: 0, tempoSoma: 0 },
      'Trigonometria - Intermediário': { total: 0, erros: 0, tempoSoma: 0 },
      'Trigonometria - Avançado': { total: 0, erros: 0, tempoSoma: 0 }
    };

    let totalTempo = 0;

    tentativas.forEach((a) => {
      const chave = a.temaNome || 'Outro';
      if (!themeMap[chave]) themeMap[chave] = { total: 0, erros: 0, tempoSoma: 0 };
      themeMap[chave].total += 1;
      if (!a.acertou) themeMap[chave].erros += 1;
      const tempo = a.tempoGastoSegundos || 20;
      themeMap[chave].tempoSoma += tempo;
      totalTempo += tempo;
    });

    const temasStats: TeacherThemeStats[] = Object.entries(themeMap)
      .filter(([, dados]) => dados.total > 0)
      .map(([tema, dados]) => ({
        temaNome: tema,
        totalRespostas: dados.total,
        totalErros: dados.erros,
        taxaErroPercentual: Math.round((dados.erros / dados.total) * 100),
        tempoMedioSegundos: Math.round(dados.tempoSoma / dados.total)
      }))
      .sort((a, b) => b.taxaErroPercentual - a.taxaErroPercentual);

    return {
      temasStats,
      temaCriticoGeral:
        temasStats.length > 0 && temasStats[0].totalErros > 0
          ? `${temasStats[0].temaNome} (${temasStats[0].taxaErroPercentual}% de erros)`
          : 'Nenhum tema com erros elevados',
      tempoMedioGeralEscola: tentativas.length > 0 ? Math.round(totalTempo / tentativas.length) : 0,
      totalTentativasGeral: tentativas.length
    };
  }
};

/* -------------------------------------------------------------------------- */
/* Inicialização automática                                                    */
/* -------------------------------------------------------------------------- */

if (typeof window !== 'undefined') {
  initSync();
}

// Reexportado para quem preferir importar o tipo do erro de API
export { ApiError };
