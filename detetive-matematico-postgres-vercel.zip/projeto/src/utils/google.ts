/**
 * Entrada com conta Google (opcional).
 *
 * Usa o Google Identity Services (GIS) de forma leve: o script oficial só é
 * carregado quando o usuário clica no botão. O ID token devolvido é validado
 * pelo servidor (POST /api/auth/google) antes de liberar o acesso.
 *
 * Para habilitar, defina VITE_GOOGLE_CLIENT_ID (.env.local e Vercel) e cadastre
 * o domínio do site em "Origens JavaScript autorizadas" no Google Cloud Console.
 */
const CLIENT_ID = ((import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined) || '').trim();
const GIS_SRC = 'https://accounts.google.com/gsi/client';

interface GisNotification {
  isNotDisplayed?: () => boolean;
  isSkippedMoment?: () => boolean;
  getNotDisplayedReason?: () => string;
  getSkippedReason?: () => string;
}

interface GisAccounts {
  id: {
    initialize: (config: Record<string, unknown>) => void;
    prompt: (callback?: (notification: GisNotification) => void) => void;
    disableAutoSelect: () => void;
  };
}

function gis(): GisAccounts | undefined {
  return (window as unknown as { google?: { accounts?: GisAccounts } }).google?.accounts;
}

export function isGoogleSignInEnabled(): boolean {
  return CLIENT_ID.length > 0;
}

let carregamento: Promise<void> | null = null;

function carregarScript(): Promise<void> {
  if (typeof document === 'undefined') {
    return Promise.reject(new Error('Entrada com Google indisponível neste ambiente.'));
  }
  if (gis()?.id) return Promise.resolve();

  if (!carregamento) {
    carregamento = new Promise<void>((resolve, reject) => {
      const script = document.createElement('script');
      script.src = GIS_SRC;
      script.async = true;
      script.defer = true;
      script.onload = () => resolve();
      script.onerror = () =>
        reject(new Error('Não foi possível carregar o serviço de login do Google.'));
      document.head.appendChild(script);
    });
  }

  return carregamento;
}

/**
 * Abre o seletor de contas do Google e devolve a credencial (ID token).
 * A credencial é enviada ao servidor, que a valida junto ao Google.
 */
export async function signInWithGoogle(): Promise<{ credential: string; email: string; nome: string }> {
  if (!CLIENT_ID) {
    throw new Error(
      'A entrada com Google não está configurada nesta publicação. Configure VITE_GOOGLE_CLIENT_ID para habilitá-la ou use e-mail/RA e senha.'
    );
  }

  await carregarScript();
  const accounts = gis();
  if (!accounts?.id) throw new Error('Serviço de login do Google indisponível no momento.');

  const credencial = await new Promise<string>((resolve, reject) => {
    let respondido = false;

    accounts.id.initialize({
      client_id: CLIENT_ID,
      auto_select: false,
      cancel_on_tap_outside: true,
      use_fedcm_for_prompt: true,
      callback: (resposta: { credential?: string }) => {
        respondido = true;
        if (resposta?.credential) resolve(resposta.credential);
        else reject(new Error('O Google não devolveu uma credencial válida.'));
      }
    });

    accounts.id.prompt((notification: GisNotification) => {
      if (respondido) return;
      if (notification?.isNotDisplayed?.() || notification?.isSkippedMoment?.()) {
        respondido = true;
        const motivo =
          notification.getNotDisplayedReason?.() || notification.getSkippedReason?.() || '';
        if (motivo === 'unregistered_origin') {
          reject(
            new Error(
              'Este domínio não está autorizado no Google Cloud Console. Cadastre a URL do site em "Origens JavaScript autorizadas".'
            )
          );
          return;
        }
        reject(
          new Error(
            'O seletor de contas do Google não pôde ser exibido. Verifique se o navegador não está bloqueando janelas e tente novamente.'
          )
        );
      }
    });
  });

  const perfil = decodificarCredencialGoogle(credencial);
  return {
    credential: credencial,
    email: perfil?.email || '',
    nome: perfil?.nome || ''
  };
}

/**
 * Lê os dados visíveis do ID token SEM validar a assinatura.
 * Usado apenas como apoio no modo local; no modo nuvem a validação é feita
 * obrigatoriamente pelo servidor.
 */
export function decodificarCredencialGoogle(
  credential: string
): { email: string; nome: string; picture?: string } | null {
  try {
    const partes = credential.split('.');
    if (partes.length < 2) return null;

    const base64 = partes[1].replace(/-/g, '+').replace(/_/g, '/');
    const preenchido = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
    const binario = atob(preenchido);
    const bytes = Uint8Array.from(binario, (caractere) => caractere.charCodeAt(0));
    const dados = JSON.parse(new TextDecoder().decode(bytes)) as Record<string, unknown>;

    const email = typeof dados.email === 'string' ? dados.email : '';
    if (!email) return null;

    return {
      email,
      nome: typeof dados.name === 'string' && dados.name ? dados.name : email,
      picture: typeof dados.picture === 'string' ? dados.picture : undefined
    };
  } catch {
    return null;
  }
}