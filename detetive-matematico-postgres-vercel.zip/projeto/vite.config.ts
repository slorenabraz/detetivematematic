import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.')
      }
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      // Permite acesso por URLs públicas de ambientes de desenvolvimento
      // (Codespaces, túneis, preview do sandbox). Não afeta a Vercel.
      allowedHosts: true as true,
      hmr: process.env.DISABLE_HMR !== 'true',
      // Em desenvolvimento, encaminha /api para o servidor local (server/dev-server.ts).
      // Em produção (Vercel) as mesmas rotas são Serverless Functions.
      proxy: {
        '/api': {
          target: process.env.API_PROXY_TARGET || 'http://localhost:3001',
          changeOrigin: true
        }
      }
    },
    preview: {
      port: 4173,
      host: '0.0.0.0',
      allowedHosts: true as true,
      proxy: {
        '/api': {
          target: process.env.API_PROXY_TARGET || 'http://localhost:3001',
          changeOrigin: true
        }
      }
    }
  };
});
