/**
 * Servidor de desenvolvimento: expõe exatamente as mesmas rotas de /api que a
 * Vercel executa em produção, porém rodando localmente na porta 3001.
 *
 * Uso: npm run dev:api     (ou npm run dev, que sobe web + api juntos)
 */
import { loadEnv } from './loadEnv';

loadEnv();

import express from 'express';
import { databaseHost, isDatabaseConfigured } from '../api/_lib/db';

import healthRoute from '../api/health';
import dataRoute from '../api/data';
import importRoute from '../api/import';
import rankingRoute from '../api/ranking';
import analyticsTeacherRoute from '../api/analytics/teacher';
import loginRoute from '../api/auth/login';
import registerRoute from '../api/auth/register';
import googleRoute from '../api/auth/google';
import resetPasswordRoute from '../api/auth/reset-password';
import usersRoute from '../api/users/index';
import userByIdRoute from '../api/users/[id]';
import resultsRoute from '../api/results/index';
import attemptsRoute from '../api/attempts/index';
import reportsRoute from '../api/reports/index';

const PORT = Number(process.env.API_PORT || 3001);

type Handler = (req: unknown, res: unknown) => unknown;

const rotas: Array<[string, Handler]> = [
  ['/api/health', healthRoute as unknown as Handler],
  ['/api/data', dataRoute as unknown as Handler],
  ['/api/import', importRoute as unknown as Handler],
  ['/api/ranking', rankingRoute as unknown as Handler],
  ['/api/analytics/teacher', analyticsTeacherRoute as unknown as Handler],
  ['/api/auth/login', loginRoute as unknown as Handler],
  ['/api/auth/register', registerRoute as unknown as Handler],
  ['/api/auth/google', googleRoute as unknown as Handler],
  ['/api/auth/reset-password', resetPasswordRoute as unknown as Handler],
  ['/api/users', usersRoute as unknown as Handler],
  ['/api/users/:id', userByIdRoute as unknown as Handler],
  ['/api/results', resultsRoute as unknown as Handler],
  ['/api/attempts', attemptsRoute as unknown as Handler],
  ['/api/reports', reportsRoute as unknown as Handler]
];

const app = express();
app.use(express.json({ limit: '8mb' }));

for (const [path, handler] of rotas) {
  app.all(path, (req, res) => {
    void handler(req, res);
  });
}

app.use((req, res) => {
  res.status(404).json({ ok: false, error: `Rota não encontrada: ${req.method} ${req.path}` });
});

app.listen(PORT, '0.0.0.0', () => {
  const banco = isDatabaseConfigured()
    ? `PostgreSQL (${databaseHost()})`
    : 'não configurado — o app funcionará em MODO LOCAL até você definir DATABASE_URL';
  console.log(`\n[api] Servidor local de desenvolvimento ativo em http://localhost:${PORT}`);
  console.log(`[api] Banco de dados: ${banco}`);
  console.log('[api] Rotas disponíveis em /api/health, /api/data, /api/auth/*, /api/users, /api/results, /api/attempts, /api/reports\n');
});
