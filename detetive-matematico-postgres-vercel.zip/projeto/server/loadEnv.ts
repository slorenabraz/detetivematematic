/**
 * Carregador de .env sem dependências externas (usado pelo servidor local e
 * pelos scripts de banco). Na Vercel as variáveis vêm do painel do projeto.
 */
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

export function loadEnv(files: string[] = ['.env.local', '.env']): void {
  for (const file of files) {
    const path = resolve(process.cwd(), file);
    if (!existsSync(path)) continue;

    let conteudo = '';
    try {
      conteudo = readFileSync(path, 'utf8');
    } catch {
      continue;
    }

    for (const linha of conteudo.split(/\r?\n/)) {
      const trimmed = linha.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;

      const separador = trimmed.indexOf('=');
      if (separador === -1) continue;

      const chave = trimmed.slice(0, separador).trim();
      let valor = trimmed.slice(separador + 1).trim();

      if (
        (valor.startsWith('"') && valor.endsWith('"')) ||
        (valor.startsWith("'") && valor.endsWith("'"))
      ) {
        valor = valor.slice(1, -1);
      }

      if (!chave) continue;
      if (process.env[chave] === undefined) process.env[chave] = valor;
    }
  }
}