/**
 * Aplica o esquema do banco de dados (tabelas, índices e views).
 * O banco não recebe usuários automaticamente; o cadastro é feito pela plataforma.
 *
 *   npm run db:migrate
 *
 * Usa a variável DATABASE_URL definida em .env.local / .env.
 */
import { loadEnv } from '../server/loadEnv';

loadEnv();

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { databaseHost, ensureSchema, getPool, isDatabaseConfigured } from '../api/_lib/db';
import { counts } from '../api/_lib/repo';

async function main(): Promise<void> {
  if (!isDatabaseConfigured()) {
    console.error('\n[db] DATABASE_URL não configurada.');
    console.error('[db] Crie um arquivo .env.local com a linha: DATABASE_URL="postgresql://..."\n');
    process.exit(1);
  }

  console.log(`[db] Aplicando esquema em ${databaseHost()}...`);
  await ensureSchema();

  // Garante paridade com o arquivo SQL versionado em db/schema.sql
  const schemaPath = resolve(process.cwd(), 'db/schema.sql');
  const schemaSql = readFileSync(schemaPath, 'utf8');
  await getPool().query(schemaSql);

  const totais = await counts();
  console.log('[db] Esquema aplicado com sucesso!');
  console.log(`[db] Tabelas: users (${totais.users}), results (${totais.results}), attempts (${totais.attempts})`);
}

main()
  .catch((error) => {
    console.error('[db] Falha ao aplicar o esquema:', error);
    process.exitCode = 1;
  })
  .finally(async () => {
    try {
      await getPool().end();
    } catch {
      /* ignora */
    }
  });
