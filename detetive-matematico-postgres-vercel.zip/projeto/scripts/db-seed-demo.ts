/**
 * (OPCIONAL) Popula o banco com alunos, resultados e tentativas de exemplo,
 * para que o ranking e o painel do professor já apareçam preenchidos.
 *
 *   npm run db:seed:demo
 *
 * Use apenas em ambiente de teste/apresentação.
 */
import { loadEnv } from '../server/loadEnv';

loadEnv();

import { ensureSchema, getPool, isDatabaseConfigured } from '../api/_lib/db';
import { importBulk, type QuestionAttempt, type SessionResult } from '../api/_lib/repo';

const SERIES = [
  '8º Ano Fundamental',
  '9º Ano Fundamental',
  '1º Ano Ensino Médio',
  '2º Ano Ensino Médio'
];

const TEMAS = [
  'Teorema de Pitágoras',
  'Lei dos Senos',
  'Lei dos Cossenos',
  'Relações de Semelhança',
  'Trigonometria - Iniciante',
  'Trigonometria - Intermediário',
  'Trigonometria - Avançado'
];

const NOMES = [
  'Ana Beatriz Souza',
  'Bruno Carvalho',
  'Camila Rodrigues',
  'Davi Luiz Martins',
  'Eduarda Nogueira',
  'Felipe Andrade',
  'Gabriela Menezes',
  'Henrique Barbosa',
  'Isabela Ferraz',
  'João Pedro Lima',
  'Karolina Dias',
  'Lucas Teixeira'
];

const aleatorio = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;

async function main(): Promise<void> {
  if (!isDatabaseConfigured()) {
    console.error('\n[seed] DATABASE_URL não configurada. Configure o .env.local antes de rodar.\n');
    process.exit(1);
  }

  await ensureSchema();

  const usuarios = NOMES.map((nome, indice) => ({
    id: `demo-aluno-${indice + 1}`,
    nome,
    tipo: 'aluno' as const,
    email: `aluno${indice + 1}@exemplo.com`,
    senha: '',
    serie: SERIES[indice % SERIES.length],
    materia: '',
    data_cadastro: new Date().toLocaleDateString('pt-BR')
  }));

  const results: SessionResult[] = [];
  const attempts: QuestionAttempt[] = [];

  usuarios.forEach((usuario, indice) => {
    const quantidadeSessoes = aleatorio(2, 4);

    for (let sessao = 0; sessao < quantidadeSessoes; sessao += 1) {
      const base = Date.now() - aleatorio(1, 20) * 86400000;
      const acertos = aleatorio(4, 8);
      const erros = aleatorio(0, 4);
      const tempoMedio = aleatorio(18, 55);

      results.push({
        id: `demo-res-${indice + 1}-${sessao + 1}`,
        usuarioId: usuario.id,
        alunoNome: usuario.nome,
        serie: usuario.serie,
        modo: sessao % 2 === 0 ? 'oficial' : 'treine_mais',
        etapaNome: sessao % 2 === 0 ? 'Desafio Oficial Invertido (4 Etapas)' : 'Treine Mais — 15 Questões',
        acertos,
        erros,
        tempoTotalSegundos: (acertos + erros) * tempoMedio,
        tempoMedioPorQuestao: tempoMedio,
        data: new Date(base).toLocaleDateString('pt-BR'),
        timestamp: base
      });

      for (let questao = 0; questao < acertos + erros; questao += 1) {
        const tema = TEMAS[aleatorio(0, TEMAS.length - 1)];
        const acertou = questao < acertos;
        attempts.push({
          id: `demo-att-${indice + 1}-${sessao + 1}-${questao + 1}`,
          usuarioId: usuario.id,
          alunoNome: usuario.nome,
          serie: usuario.serie,
          modo: sessao % 2 === 0 ? 'oficial' : 'treine_mais',
          etapaNumero: sessao + 1,
          temaNome: tema,
          pergunta: `Questão de exemplo sobre ${tema}`,
          respostaSelecionada: acertou ? 'Alternativa correta' : 'Alternativa incorreta',
          respostaCorreta: 'Alternativa correta',
          acertou,
          tempoGastoSegundos: aleatorio(8, 60),
          data: new Date(base).toLocaleDateString('pt-BR'),
          timestamp: base + questao * 1000
        });
      }
    }
  });

  const resultado = await importBulk({ users: usuarios, results, attempts });

  console.log('[seed] Dados de demonstração inseridos:');
  console.log(`       ${resultado.users} alunos, ${resultado.results} resultados, ${resultado.attempts} tentativas`);
  console.log('[seed] Senha dos alunos de exemplo: vazia (entre com o e-mail e qualquer senha não funcionará — use cadastro próprio)');
  console.log('[seed] Dica: para testar o login, cadastre um aluno pela própria plataforma.\n');
}

main()
  .catch((error) => {
    console.error('[seed] Falha ao inserir dados de demonstração:', error);
    process.exitCode = 1;
  })
  .finally(async () => {
    try {
      await getPool().end();
    } catch {
      /* ignora */
    }
  });