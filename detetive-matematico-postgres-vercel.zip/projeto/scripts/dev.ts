/**
 * Sobe em paralelo o front-end (Vite na porta 3000) e a API local (porta 3001).
 * O Vite faz proxy de /api para a API, então tudo funciona na mesma origem.
 */
import { spawn, type ChildProcess } from 'node:child_process';

const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';

const processos: ChildProcess[] = [];
let encerrando = false;

function encerrar(codigo = 0): void {
  if (encerrando) return;
  encerrando = true;
  processos.forEach((processo) => {
    if (!processo.killed) processo.kill('SIGTERM');
  });
  setTimeout(() => process.exit(codigo), 300);
}

function iniciar(script: string): void {
  const processo = spawn(npm, ['run', script], { stdio: 'inherit', env: process.env });
  processos.push(processo);
  processo.on('exit', (codigo) => {
    if (!encerrando) encerrar(codigo ?? 0);
  });
}

console.log('[dev] Iniciando API local e servidor web...');
iniciar('dev:api');
iniciar('dev:web');

process.on('SIGINT', () => encerrar(0));
process.on('SIGTERM', () => encerrar(0));