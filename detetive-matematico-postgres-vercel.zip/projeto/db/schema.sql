-- ============================================================================
--  DETETIVE MATEMÁTICO — Esquema do banco de dados (PostgreSQL)
--  Compatível com: Neon, Vercel Postgres, Supabase, Railway, RDS, Docker, etc.
--  Este script é 100% idempotente: pode ser executado quantas vezes quiser.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 0. Metadados / controle de versão do esquema
-- ---------------------------------------------------------------------------
create table if not exists app_meta (
  key           text primary key,
  value         text not null,
  atualizado_em timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- 1. Usuários (alunos e professores)
-- ---------------------------------------------------------------------------
create table if not exists users (
  id            text primary key,
  nome          text not null,
  tipo          text not null check (tipo in ('aluno', 'professor')),
  email         text not null,
  senha         text not null default '',   -- hash scrypt (nunca texto puro)
  serie         text not null default '',
  materia       text not null default '',
  data_cadastro text not null default '',
  criado_em     timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

-- Um e-mail só pode existir uma vez (comparação sem diferenciar maiúsculas)
create unique index if not exists users_email_lower_key on users (lower(email));
create index if not exists users_tipo_idx  on users (tipo);
create index if not exists users_serie_idx on users (serie);

-- ---------------------------------------------------------------------------
-- 2. Resultados de sessão (base do ranking por sala)
-- ---------------------------------------------------------------------------
create table if not exists results (
  id                      text primary key,
  usuario_id              text not null,
  aluno_nome              text not null,
  serie                   text not null default '',
  modo                    text not null check (modo in ('oficial', 'treine_mais')),
  etapa_nome              text not null default '',
  acertos                 integer not null default 0,
  erros                   integer not null default 0,
  tempo_total_segundos    double precision not null default 0,
  tempo_medio_por_questao double precision not null default 0,
  data                    text not null default '',
  timestamp               bigint not null default 0,
  criado_em               timestamptz not null default now()
);

create index if not exists results_usuario_idx   on results (usuario_id);
create index if not exists results_serie_idx     on results (serie);
create index if not exists results_timestamp_idx on results (timestamp desc);

-- ---------------------------------------------------------------------------
-- 3. Tentativas individuais (diagnóstico pedagógico do professor)
-- ---------------------------------------------------------------------------
create table if not exists attempts (
  id                   text primary key,
  usuario_id           text not null,
  aluno_nome           text not null,
  serie                text not null default '',
  modo                 text not null check (modo in ('oficial', 'treine_mais')),
  etapa_numero         integer not null default 1,
  tema_nome            text not null default '',
  pergunta             text not null default '',
  resposta_selecionada text not null default '',
  resposta_correta     text not null default '',
  acertou              boolean not null default false,
  tempo_gasto_segundos double precision not null default 0,
  data                 text not null default '',
  timestamp            bigint not null default 0,
  criado_em            timestamptz not null default now()
);

create index if not exists attempts_usuario_idx   on attempts (usuario_id);
create index if not exists attempts_serie_idx     on attempts (serie);
create index if not exists attempts_tema_idx      on attempts (tema_nome);
create index if not exists attempts_timestamp_idx on attempts (timestamp desc);

-- ---------------------------------------------------------------------------
-- 4. Relatos de erros enviados pelos alunos para o painel docente
-- ---------------------------------------------------------------------------
create table if not exists challenge_reports (
  id            text primary key,
  usuario_id    text not null,
  aluno_nome    text not null,
  serie         text not null default '',
  desafio_nome  text not null,
  modo          text not null check (modo in ('oficial', 'treine_mais')),
  descricao     text not null check (char_length(descricao) between 5 and 500),
  status        text not null default 'aberto' check (status in ('aberto', 'resolvido')),
  data          text not null default '',
  timestamp     bigint not null default 0,
  criado_em     timestamptz not null default now()
);
create index if not exists challenge_reports_status_idx on challenge_reports (status, timestamp desc);
create index if not exists challenge_reports_serie_idx on challenge_reports (serie);

-- ---------------------------------------------------------------------------
-- 5. Views de apoio (consultas prontas para ranking e análise por tema)
-- ---------------------------------------------------------------------------
create or replace view vw_ranking_alunos as
select
  r.usuario_id,
  max(r.aluno_nome)                                as aluno_nome,
  max(r.serie)                                     as serie,
  sum(r.acertos)::int                              as total_acertos,
  sum(r.erros)::int                                as total_erros,
  count(*)::int                                    as desafios_concluidos,
  coalesce(sum(r.tempo_total_segundos), 0)         as soma_tempo_segundos,
  case when sum(r.acertos + r.erros) > 0
       then round((sum(r.acertos)::numeric / sum(r.acertos + r.erros)) * 100)::int
       else 0 end                                  as aproveitamento,
  case when sum(r.acertos + r.erros) > 0
       then round(sum(r.tempo_total_segundos) / sum(r.acertos + r.erros))::int
       else 0 end                                  as tempo_medio_segundos
from results r
group by r.usuario_id;

create or replace view vw_desempenho_por_tema as
select
  a.tema_nome,
  a.serie,
  count(*)::int                                                  as total_respostas,
  count(*) filter (where not a.acertou)::int                     as total_erros,
  case when count(*) > 0
       then round((count(*) filter (where not a.acertou))::numeric / count(*) * 100)::int
       else 0 end                                                as taxa_erro_percentual,
  round(avg(a.tempo_gasto_segundos))::int                        as tempo_medio_segundos
from attempts a
group by a.tema_nome, a.serie;

-- ---------------------------------------------------------------------------
-- 6. Versão do esquema
-- ---------------------------------------------------------------------------
insert into app_meta (key, value) values ('schema_version', '2')
on conflict (key) do update set value = excluded.value, atualizado_em = now();
