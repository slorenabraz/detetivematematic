# 🕵️‍♂️ DETETIVE MATEMÁTICO — Banco de dados + Deploy na Vercel

> Plataforma pedagógica de **Geometria e Trigonometria** com desafios investigativos,
> ranking por sala e painel analítico para professores.
> Desenvolvido por **Profª Ariane Braz**.

Esta versão substitui o armazenamento antigo (Firebase/Firestore + navegador) por um
**banco de dados PostgreSQL próprio**, acessado por uma **API serverless** que roda
dentro da própria Vercel. Tudo o que alunos e professores fazem fica salvo no banco:
cadastros, senhas (com hash), resultados de desafios, tentativas de cada questão,
tempos de resposta e ranking. O projeto está pronto para publicar na Vercel.

---

## 📌 Índice

1. [O que mudou](#1-o-que-mudou)
2. [Arquitetura](#2-arquitetura)
3. [Publicar na Vercel (passo a passo)](#3-publicar-na-vercel-passo-a-passo)
4. [Variáveis de ambiente](#4-variáveis-de-ambiente)
5. [Banco de dados](#5-banco-de-dados)
6. [Rodar no seu computador](#6-rodar-no-seu-computador)
7. [Contas de acesso](#7-contas-de-acesso)
8. [Referência da API](#8-referência-da-api)
9. [Modo local (sem banco)](#9-modo-local-sem-banco)
10. [Como funciona a sincronização](#10-como-funciona-a-sincronização)
11. [Segurança](#11-segurança)
12. [Solução de problemas](#12-solução-de-problemas)
13. [Estrutura de arquivos](#13-estrutura-de-arquivos)

---

## 1. O que mudou

| Antes | Agora |
| --- | --- |
| Firebase Firestore (configuração de outro projeto, `firebase-applet-config.json`) | **PostgreSQL** com esquema próprio (`db/schema.sql`) |
| Senhas em texto puro gravadas no navegador e no banco | **Hash scrypt** com sal aleatório, gerado no servidor |
| Login comparado no navegador (senha exposta no cliente) | Login **validado no servidor**; o hash nunca sai do banco |
| Dependência `firebase` (e `@google/genai`) | Apenas `pg` (driver oficial do PostgreSQL) |
| Dados “presos” no navegador | **API serverless** na Vercel + cache local com fila de reenvio |
| Login Google via Firebase (domínio não autorizado na Vercel) | Google Identity Services opcional (`VITE_GOOGLE_CLIENT_ID`) |

Toda a interface foi preservada: as abas **Início, Desafios, Meus Resultados, Professores,
Ranking e Materiais de Apoio** continuam idênticas e agora leem/gravam no banco.

---

## 2. Arquitetura

```mermaid
flowchart LR
    A["Navegador<br/>(React + Vite)"] -->|"/api/*"| B["Funções Serverless<br/>(pasta /api)"]
    A -.->|cache + fila offline| C["localStorage"]
    B --> D["PostgreSQL<br/>users / results / attempts"]
    D --> E["Views<br/>vw_ranking_alunos<br/>vw_desempenho_por_tema"]
    B --> F["scrypt<br/>(hash de senha)"]
```

- **Front-end:** React 19 + Vite + Tailwind (o mesmo visual neon original).
- **Back-end:** funções serverless em `/api` (Node.js, sem framework obrigatório).
- **Banco:** qualquer PostgreSQL — Neon, Vercel Postgres, Supabase, Railway, RDS, Docker.
- **Esquema criado automaticamente** no primeiro acesso (nada de rodar SQL à mão). O banco começa vazio: não existe usuário de demonstração nem senha padrão; a primeira conta é criada pela tela de cadastro.

---

## 3. Publicar na Vercel (passo a passo)

### Passo 1 — Coloque o projeto no GitHub

```bash
cd detetive-matematico
git init
git add .
git commit -m "Detetive Matemático com banco PostgreSQL"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/detetive-matematico.git
git push -u origin main
```

### Passo 2 — Crie o banco de dados gratuito

**Opção A (mais simples, pelo painel da Vercel)**

1. Entre em [vercel.com](https://vercel.com) → **Storage** (ou *Marketplace*).
2. Escolha **Neon** (Postgres) → **Create Database** → plano **Free**.
3. Copie a **connection string** (`postgresql://...`).

**Opção B (direto no provedor)**

1. Crie uma conta gratuita em [neon.tech](https://neon.tech) ou [supabase.com](https://supabase.com).
2. Crie o projeto e copie a string de conexão:
   - Neon: use a URL com `-pooler` e `?sslmode=require`.
   - Supabase: use a porta do **pooler** `6543` e `?sslmode=require`.

### Passo 3 — Importe o projeto na Vercel

1. [vercel.com/new](https://vercel.com/new) → **Import Git Repository** → escolha o repositório.
2. A Vercel detecta o framework **Vite** automaticamente (`vercel.json` já está configurado):
   - Build Command: `npm run build`
   - Output Directory: `dist`
3. **Antes de clicar em Deploy**, abra *Environment Variables*.

### Passo 4 — Configure as variáveis de ambiente

| Nome | Valor | Obrigatória |
| --- | --- | --- |
| `DATABASE_URL` | string do Postgres copiada no Passo 2 | ✅ Sim |
| `DATABASE_SSL` | deixe vazio (detecção automática) | Não |
| `DEFAULT_TEACHER_EMAIL` | e-mail da professora (padrão `arianebraz3@gmail.com`) | Não |
| `DEFAULT_TEACHER_PASSWORD` | senha inicial (padrão `123`) | Não |
| `VITE_GOOGLE_CLIENT_ID` | Client ID do Google, se quiser botão “Continuar com Google” | Não |
| `GOOGLE_CLIENT_ID` | mesmo Client ID, validado no servidor | Não |

Marque as variáveis para os três ambientes (Production, Preview, Development) e clique em **Deploy**.

### Passo 5 — Confirme que o banco está ativo

Depois do deploy, abra:

```
https://SEU-PROJETO.vercel.app/api/health
```

Resposta esperada:

```json
{ "ok": true, "database": true, "configured": true, "mode": "cloud", "counts": { "users": 1, ... } }
```

Se aparecer `"database": false`, revise a `DATABASE_URL` (veja
[Solução de problemas](#12-solução-de-problemas)).

> **Pronto.** Acesse o site, faça login como professora
> (`arianebraz3@gmail.com` / senha `123` — altere depois em *Redefinir senha*) e comece a usar.

---

## 4. Variáveis de ambiente

Copie `.env.example` para `.env.local` no seu computador (esse arquivo nunca vai para o Git):

```bash
cp .env.example .env.local
```

e preencha a `DATABASE_URL`. Na Vercel, as mesmas variáveis ficam em
**Project → Settings → Environment Variables**.

---

## 5. Banco de dados

### 5.1 Tabelas

| Tabela | Conteúdo |
| --- | --- |
| `users` | Alunos e professores: nome, tipo, e-mail, **senha (hash scrypt)**, série ou disciplina, data de cadastro |
| `results` | Resultado de cada desafio concluído: acertos, erros, tempo total, tempo médio por questão (base do ranking) |
| `attempts` | Tentativa de **cada questão**: tema, pergunta, resposta escolhida, resposta correta, acertou/errou e tempo gasto (base do painel do professor) |
| `challenge_reports` | Relatos de problemas enviados pelos alunos nos cards de desafios, com descrição validada, status e histórico |
| `app_meta` | Versão do esquema (controle de migrações futuras) |

### 5.2 Consultas prontas (views)

| View | Para que serve |
| --- | --- |
| `vw_ranking_alunos` | Ranking consolidado por aluno (acertos, erros, aproveitamento, tempo médio) |
| `vw_desempenho_por_tema` | Taxa de erro e tempo médio por tema/série |

Exemplo de consulta direta no banco:

```sql
select * from vw_ranking_alunos order by total_acertos desc limit 10;

select * from vw_desempenho_por_tema
where serie = '9º Ano Fundamental'
order by taxa_erro_percentual desc;
```

### 5.3 Criar/atualizar o esquema manualmente

Na Vercel **não é necessário**: o esquema é criado automaticamente na primeira requisição.
Se quiser aplicar pelo terminal (recomendado em bancos locais):

```bash
npm run db:migrate      # cria tabelas, índices, views e a conta da professora
npm run db:seed:demo    # (opcional) 12 alunos com resultados e tentativas de exemplo
```

O arquivo `db/schema.sql` é a versão legível do esquema e pode ser colado em qualquer
console SQL (Neon, Supabase, psql).

---

## 6. Rodar no seu computador

```bash
npm install
cp .env.example .env.local     # preencha DATABASE_URL
npm run dev                    # sobe o site (3000) + API local (3001)
```

- Site: <http://localhost:3000>
- API: <http://localhost:3001/api/health>

Scripts disponíveis:

| Script | O que faz |
| --- | --- |
| `npm run dev` | Site + API local juntos |
| `npm run dev:web` | Somente o front-end (Vite) |
| `npm run dev:api` | Somente a API local (Express) |
| `npm run build` | Gera a versão de produção em `dist/` |
| `npm run preview` | Serve a versão de produção localmente |
| `npm run lint` | Verificação de tipos TypeScript |
| `npm run db:migrate` | Aplica o esquema do banco |
| `npm run db:seed:demo` | Insere dados de demonstração |

Banco local rápido com Docker:

```bash
docker run --name detetive-db -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=detetive -p 5432:5432 -d postgres:16
# DATABASE_URL="postgresql://postgres:postgres@localhost:5432/detetive"
# DATABASE_SSL="false"
```

---

## 7. Contas de acesso

| Perfil | E-mail | Senha |
| --- | --- | --- |
| Professora | Cadastre uma conta com tipo **Professor** na própria tela | Definida no cadastro |

- Alunos e professores podem se cadastrar pela própria tela **Entrar → Criar Novo Cadastro**.
- O login aceita **e-mail institucional, e-mail pessoal ou RA/usuário**, sem diferenciar
  maiúsculas de minúsculas.
- A senha pode ser redefinida na tela *Redefinir Senha* (gravada com hash no banco).

---

## 8. Referência da API

Todas as rotas ficam em `/api` e respondem JSON no formato `{ "ok": true, ... }`
ou `{ "ok": false, "error": "mensagem" }`.

| Método | Rota | Descrição |
| --- | --- | --- |
| GET | `/api/health` | Diagnóstico: banco configurado, acessível e contagens |
| GET | `/api/data` | Todo o conjunto de dados (usuários, resultados, tentativas) |
| POST | `/api/auth/login` | `{ login, senha, tipo? }` → autentica no banco |
| POST | `/api/auth/register` | `{ nome, tipo, email, senha, serie?, materia? }` → cadastra |
| POST | `/api/auth/google` | `{ credential }` → valida o ID token do Google e libera o acesso |
| POST | `/api/auth/reset-password` | `{ login, novaSenha }` → redefine a senha (com hash) |
| GET / POST | `/api/users` | Lista / cria-atualiza usuário (idempotente pelo `id`) |
| GET / PATCH / DELETE | `/api/users/:id` | Consulta, troca de senha ou remoção |
| GET / POST | `/api/results` | Resultados de desafios |
| GET / POST | `/api/attempts` | Tentativas individuais |
| GET / POST / PATCH | `/api/reports` | Relatos de erros dos cards e atualização do status docente |
| GET | `/api/ranking?serie=` | Ranking calculado no banco (view) |
| GET | `/api/analytics/teacher?serie=` | Relatório pedagógico consolidado |
| POST | `/api/import` | Importa em lote dados antigos (idempotente) |

Exemplo:

```bash
curl -X POST https://SEU-PROJETO.vercel.app/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"login":"arianebraz3@gmail.com","senha":"123"}'
```

---

## 9. Modo local (sem banco)

Se a plataforma for publicada **sem** `DATABASE_URL`, o site continua 100% funcional:
os dados ficam salvos apenas no navegador (`localStorage`) e a tela de login mostra
**“Modo local”**. Nenhuma tela quebra — é o mesmo comportamento usado como reserva
quando o banco fica momentaneamente indisponível.

Quando você configurar a `DATABASE_URL` **e** o banco estiver vazio, os dados que já
existiam naquele navegador são **migrados automaticamente** para o PostgreSQL na
primeira sincronização (a conversa de senhas antigas para hash acontece nesse momento).

---

## 10. Como funciona a sincronização

1. Ao abrir o site, o app consulta `/api/health` e depois `/api/data`.
2. Todo o conteúdo é guardado também em cache no navegador → ranking, histórico e
   painel carregam instantaneamente e continuam visíveis sem internet.
3. Cada gravação (cadastro, resposta de questão, fim de desafio) é enviada à API e,
   se a conexão falhar, fica em uma **fila de sincronização** no navegador.
4. A cada 15 segundos (ou ao voltar para a aba) o app reenvia a fila e atualiza o cache.
5. O indicador na tela de login mostra: **Sincronizado**, **Conectando...** ou **Modo local**,
   além de quantos registros estão aguardando envio. Há também o botão *Sincronizar*.

---

## 11. Segurança

- Senhas gravadas com **scrypt** (sal aleatório por usuário) — nunca em texto puro.
- O hash **nunca é enviado ao navegador**: a comparação é feita no servidor.
- Senhas antigas em texto puro (dados legados) são aceitas no primeiro login e
  convertidas automaticamente para hash.
- Todas as consultas usam **parâmetros** (`$1`, `$2`...) — sem risco de SQL injection.
- Validação de dados no servidor (tipo de acesso, tamanho de senha, e-mail duplicado,
  campos obrigatórios) e mensagens amigáveis em português.
- CORS e `Cache-Control: no-store` configurados nas rotas da API.

> Observação: o login do Google é opcional e só é habilitado quando
> `VITE_GOOGLE_CLIENT_ID` é definido **e** o domínio do site está cadastrado em
> *Origens JavaScript autorizadas* no Google Cloud Console.

---

## 12. Solução de problemas

| Sintoma | Causa provável | Solução |
| --- | --- | --- |
| `/api/health` retorna `"database": false` | `DATABASE_URL` ausente ou incorreta | Confira a variável na Vercel (Production **e** Preview) e faça um novo deploy |
| Tela mostra **Modo local** no site publicado | O banco não respondeu | Teste `/api/health`; se `configured: true` e `database: false`, o host pode estar bloqueando conexões — use a URL do *pooler* do provedor |
| Erro de SSL ao conectar | Provedor exige/não exige SSL | Defina `DATABASE_SSL=true` (remoto) ou `false` (local) |
| Muitas conexões / `too many clients` | Pool acima do limite do plano gratuito | Reduza `DATABASE_POOL_MAX` (ex.: `1`) |
| Login diz que a senha está incorreta | Senha alterada via *Redefinir senha* | Use a senha atual ou redefina novamente |
| “E-mail já cadastrado” | Cadastro duplicado (sem distinção de maiúsculas) | Use o login existente ou redefina a senha |
| Botão do Google com mensagem de configuração | `VITE_GOOGLE_CLIENT_ID` ausente ou domínio não autorizado | Cadastre o Client ID e a URL do site no Google Cloud Console |
| Ranking/painel vazios | Nenhum desafio concluído ainda | Normal no início; use `npm run db:seed:demo` para ver dados de exemplo |

Verificações úteis:

```bash
curl https://SEU-PROJETO.vercel.app/api/health
curl "https://SEU-PROJETO.vercel.app/api/ranking?serie=todos"
```

---

## 13. Estrutura de arquivos

```
detetive-matematico/
├── api/                          # Back-end serverless (Vercel Functions)
│   ├── _lib/
│   │   ├── db.ts                 # Conexão PostgreSQL + criação automática do esquema
│   │   ├── schema.ts             # Esquema SQL embutido (idempotente)
│   │   ├── repo.ts               # Consultas (usuários, resultados, tentativas, ranking)
│   │   ├── auth.ts               # Hash scrypt + validação do token do Google
│   │   └── http.ts               # Helpers de requisição/resposta/erros
│   ├── health.ts                 # GET /api/health
│   ├── data.ts                   # GET /api/data (sincronização completa)
│   ├── import.ts                 # POST /api/import (migração de dados antigos)
│   ├── ranking.ts                # GET /api/ranking
│   ├── analytics/teacher.ts      # GET /api/analytics/teacher
│   ├── auth/                     # login, register, google, reset-password
│   ├── users/                    # lista, criação, consulta, senha, remoção
│   ├── results/                  # resultados de desafios
│   └── attempts/                 # tentativas individuais
├── db/schema.sql                 # Esquema legível (tabelas, índices e views)
├── scripts/
│   ├── dev.ts                    # Sobe site + API juntos
│   ├── db-migrate.ts             # Aplica o esquema do banco
│   └── db-seed-demo.ts           # Dados de demonstração (opcional)
├── server/
│   ├── dev-server.ts             # API local (mesmas rotas da Vercel)
│   └── loadEnv.ts                # Leitor de .env sem dependências
├── src/
│   ├── components/               # Interface (abas, desafios, painéis)
│   ├── data/questions.ts         # Banco de questões de Geometria e Trigonometria
│   ├── utils/api.ts              # Cliente HTTP da API
│   ├── utils/storage.ts          # Camada de dados (banco + cache + fila offline)
│   ├── utils/google.ts           # Entrada com Google (opcional)
│   └── types.ts                  # Tipos compartilhados
├── .env.example                  # Modelo das variáveis de ambiente
├── vercel.json                   # Configuração de build/deploy da Vercel
└── package.json
```

---

### Próximos passos sugeridos (opcionais)

- Painel administrativo para exportar relatórios em CSV/Excel direto do banco.
- Sessões com token (JWT) em vez de sessão no navegador.
- Backups automáticos do banco (Neon e Supabase oferecem retenção por padrão).
- Migração das questões para o banco, permitindo criar desafios sem alterar o código.

---

**DETETIVE MATEMÁTICO • Todo desafio tem uma solução!** 🕵️‍♂️📐
